from setuptools import setup, find_packages

setup(
    name="healthcare-demand-engine",
    version="0.1.0",
    description="AI-assisted healthcare provider demand segmentation, "
                "POI scoring, and GTM test generation via SQL agents.",
    author="Naphekie Taloute",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "pyyaml>=6.0",
        "python-dotenv>=1.0.0",
        "tabulate>=0.9.0",
    ],
    extras_require={
        "llm": ["anthropic>=0.39.0"],
        "api": ["fastapi>=0.115.0", "uvicorn>=0.32.0", "pydantic>=2.0.0"],
        "dev": ["pytest>=8.0.0", "pytest-cov>=5.0.0", "structlog>=24.0.0"],
    },
    entry_points={
        "console_scripts": [
            "demand-engine=src.main:main",
        ],
    },
)
