"""
Test Suite — Healthcare Provider Demand Engine
================================================
Tests all 4 agent components + POI scorer against the mock database.
Run: pytest tests/ -v
"""

import pytest
import sqlite3
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils.database import init_database, execute_query
from src.utils.config import load_schema_config, load_guardrails_config, get_schema_prompt
from src.agents.sql_query_agent import SQLQueryAgent
from src.validators.schema_validator import SchemaValidator
from src.explainers.result_explainer import ResultExplainer
from src.generators.gtm_test_generator import GTMTestGenerator
from src.models.poi_scorer import POIScorer


# ---- Fixtures ----

@pytest.fixture(scope="session")
def db_conn():
    """Create an in-memory test database with full schema and seed data."""
    conn = init_database(":memory:")
    yield conn
    conn.close()


@pytest.fixture(scope="session")
def schema():
    return load_schema_config()


@pytest.fixture(scope="session")
def guardrails():
    return load_guardrails_config()


@pytest.fixture(scope="session")
def sql_agent(db_conn, schema):
    prompt = get_schema_prompt(schema)
    return SQLQueryAgent(db_conn, llm_client=None, schema_prompt=prompt)


@pytest.fixture(scope="session")
def validator(db_conn, guardrails, schema):
    return SchemaValidator(db_conn, guardrails, schema)


@pytest.fixture(scope="session")
def explainer():
    return ResultExplainer(llm_client=None)


@pytest.fixture(scope="session")
def gtm_gen():
    return GTMTestGenerator(llm_client=None)


@pytest.fixture(scope="session")
def poi_scorer(db_conn):
    return POIScorer(db_conn)


# ============================================================================
# TEST: Database Initialization
# ============================================================================

class TestDatabase:
    def test_tables_exist(self, db_conn):
        tables = db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
        table_names = {row[0] for row in tables}
        assert "geo_markets" in table_names
        assert "providers" in table_names
        assert "search_events" in table_names
        assert "bookings" in table_names
        assert "agent_runs" in table_names
        assert "poi_scores" in table_names

    def test_views_exist(self, db_conn):
        views = db_conn.execute(
            "SELECT name FROM sqlite_master WHERE type='view'"
        ).fetchall()
        view_names = {row[0] for row in views}
        assert "v_demand_signals" in view_names
        assert "v_supply_metrics" in view_names
        assert "v_booking_performance" in view_names
        assert "v_poi_ranking" in view_names
        assert "v_gtm_segments" in view_names

    def test_seed_data_loaded(self, db_conn):
        geo_count = db_conn.execute("SELECT COUNT(*) FROM geo_markets").fetchone()[0]
        assert geo_count >= 20

        prov_count = db_conn.execute("SELECT COUNT(*) FROM providers").fetchone()[0]
        assert prov_count >= 30

        search_count = db_conn.execute("SELECT COUNT(*) FROM search_events").fetchone()[0]
        assert search_count >= 50

        book_count = db_conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
        assert book_count >= 40

    def test_execute_query_with_limit(self, db_conn):
        rows = execute_query(db_conn, "SELECT * FROM geo_markets", limit=5)
        assert len(rows) <= 5
        assert isinstance(rows[0], dict)
        assert "city" in rows[0]


# ============================================================================
# TEST: Component 1 — SQL Query Agent
# ============================================================================

class TestSQLQueryAgent:
    def test_template_match_poi(self, sql_agent):
        result = sql_agent.generate("top segments by POI")
        assert result["sql"] is not None
        assert "v_poi_ranking" in result["sql"]
        assert result["source"] == "template"

    def test_template_match_demand(self, sql_agent):
        result = sql_agent.generate("top search demand by specialty")
        assert result["sql"] is not None
        assert "search_events" in result["sql"]
        assert result["source"] == "template"

    def test_template_match_bookings(self, sql_agent):
        result = sql_agent.generate("booking metrics by specialty")
        assert result["sql"] is not None
        assert "v_booking_performance" in result["sql"]

    def test_template_match_provider_count(self, sql_agent):
        result = sql_agent.generate("how many providers in Phoenix")
        assert result["sql"] is not None
        assert "Phoenix" in result["sql"]

    def test_template_match_gtm(self, sql_agent):
        result = sql_agent.generate("gtm recommendations")
        assert result["sql"] is not None
        assert "v_gtm_segments" in result["sql"]

    def test_template_match_supply_demand(self, sql_agent):
        result = sql_agent.generate("supply demand gap")
        assert result["sql"] is not None
        assert "v_supply_demand_gap" in result["sql"]

    def test_template_match_cpa(self, sql_agent):
        result = sql_agent.generate("average CPA by specialty")
        assert result["sql"] is not None
        assert "cpa" in result["sql"].lower()

    def test_no_match_returns_llm_unavailable(self, sql_agent):
        result = sql_agent.generate("what is the meaning of life")
        # No template match, no LLM → should indicate LLM unavailable
        assert result.get("source") in ("llm_unavailable", "llm_error", "template")

    def test_generate_and_execute(self, sql_agent):
        result = sql_agent.generate_and_execute("show all markets")
        assert result.get("results") is not None
        assert result["row_count"] >= 10

    def test_latency_recorded(self, sql_agent):
        result = sql_agent.generate("top segments by POI")
        assert "latency_ms" in result
        assert result["latency_ms"] >= 0

    def test_parametric_query(self, sql_agent):
        result = sql_agent.generate("demand for Dermatology in Miami")
        assert result["sql"] is not None
        assert "Dermatology" in result["sql"]
        assert "Miami" in result["sql"]


# ============================================================================
# TEST: Component 2 — Schema Validator
# ============================================================================

class TestSchemaValidator:
    def test_valid_select(self, validator):
        result = validator.validate("SELECT * FROM providers LIMIT 10")
        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_blocks_drop(self, validator):
        result = validator.validate("DROP TABLE providers")
        assert result["valid"] is False
        assert any("BLOCKED_OPERATION" in e for e in result["errors"])

    def test_blocks_delete(self, validator):
        result = validator.validate("DELETE FROM bookings WHERE 1=1")
        assert result["valid"] is False

    def test_blocks_insert(self, validator):
        result = validator.validate("INSERT INTO providers VALUES ('x')")
        assert result["valid"] is False

    def test_blocks_pii_column(self, validator):
        result = validator.validate("SELECT patient_name FROM providers LIMIT 10")
        assert result["valid"] is False
        assert any("PII" in e or "BLOCKED" in e for e in result["errors"])

    def test_blocks_unauthorized_table(self, validator):
        result = validator.validate("SELECT * FROM sqlite_master LIMIT 10")
        assert result["valid"] is False
        assert any("UNAUTHORIZED_TABLE" in e for e in result["errors"])

    def test_auto_adds_limit(self, validator):
        result = validator.validate("SELECT * FROM providers")
        assert "LIMIT" in result["sql"].upper()
        assert any("AUTO_LIMIT" in w for w in result["warnings"])

    def test_caps_excessive_limit(self, validator):
        result = validator.validate("SELECT * FROM providers LIMIT 50000")
        assert "LIMIT 1000" in result["sql"]

    def test_valid_view_query(self, validator):
        result = validator.validate("SELECT * FROM v_poi_ranking LIMIT 10")
        assert result["valid"] is True

    def test_valid_join(self, validator):
        sql = """
            SELECT p.specialty, g.city
            FROM providers p
            JOIN geo_markets g ON p.geo_id = g.geo_id
            LIMIT 10
        """
        result = validator.validate(sql)
        assert result["valid"] is True

    def test_syntax_error_caught(self, validator):
        result = validator.validate("SELECTT * FROMM providers LIMIT 10")
        assert result["valid"] is False
        assert any("SYNTAX" in e.upper() or "BLOCKED" in e.upper() for e in result["errors"])

    def test_report_format(self, validator):
        result = validator.validate_and_report("SELECT * FROM providers LIMIT 10")
        assert "report" in result
        assert "PASS" in result["report"]


# ============================================================================
# TEST: Component 3 — Result Explainer
# ============================================================================

class TestResultExplainer:
    def test_empty_results(self, explainer):
        result = explainer.explain("test", "SELECT 1", [])
        assert "no results" in result["explanation"].lower()
        assert result["ai_generated"] is True

    def test_poi_results_explanation(self, explainer):
        mock_results = [
            {"specialty": "Dermatology", "city": "Miami", "poi": 82, "rank": 1,
             "demand_score": 85, "supply_gap_score": 75},
            {"specialty": "Cardiology", "city": "Phoenix", "poi": 78, "rank": 2,
             "demand_score": 72, "supply_gap_score": 68},
            {"specialty": "Pediatrics", "city": "Austin", "poi": 74, "rank": 3,
             "demand_score": 68, "supply_gap_score": 70},
        ]
        result = explainer.explain("top segments", "SELECT...", mock_results)
        assert "Dermatology" in result["explanation"]
        assert result["ai_generated"] is True

    def test_demand_results_explanation(self, explainer):
        mock_results = [
            {"specialty": "Dermatology", "search_volume": 150, "avg_ctr": 0.42},
        ]
        result = explainer.explain("search demand", "SELECT...", mock_results)
        assert "Dermatology" in result["explanation"]
        assert "150" in result["explanation"]

    def test_booking_results_explanation(self, explainer):
        mock_results = [
            {"specialty": "Cardiology", "total_bookings": 45, "avg_cpa": 55.00,
             "completion_rate": 0.85},
        ]
        result = explainer.explain("bookings", "SELECT...", mock_results)
        assert "Cardiology" in result["explanation"]

    def test_pin_check_high_cpa(self, explainer):
        mock_results = [{"avg_cpa": 350.00}]
        result = explainer.explain("test", "SELECT...", mock_results)
        assert len(result["pin_checks"]) > 0
        assert any("High CPA" in c for c in result["pin_checks"])

    def test_pin_check_low_completion(self, explainer):
        mock_results = [{"completion_rate": 0.25}]
        result = explainer.explain("test", "SELECT...", mock_results)
        assert any("low completion" in c.lower() for c in result["pin_checks"])

    def test_gtm_explanation(self, explainer):
        mock_results = [
            {"segment": "Dermatology - Miami", "poi": 82,
             "why_it_matters": "High search demand, low provider coverage — recruit providers"},
        ]
        result = explainer.explain("gtm", "SELECT...", mock_results)
        assert "Dermatology" in result["explanation"]
        assert "recruit" in result["explanation"].lower()


# ============================================================================
# TEST: Component 4 — GTM Test Generator
# ============================================================================

class TestGTMTestGenerator:
    def test_classify_high_demand_low_supply(self, gtm_gen):
        row = {"demand_score": 80, "supply_gap_score": 85, "conversion_score": 30,
               "growth_score": 40, "avg_cpa": 60}
        assert gtm_gen.classify_segment(row) == "high_demand_low_supply"

    def test_classify_strong_conversion(self, gtm_gen):
        row = {"demand_score": 50, "supply_gap_score": 40, "conversion_score": 70,
               "growth_score": 40, "avg_cpa": 35}
        assert gtm_gen.classify_segment(row) == "strong_conversion_low_cpa"

    def test_classify_high_growth(self, gtm_gen):
        row = {"demand_score": 55, "supply_gap_score": 40, "conversion_score": 40,
               "growth_score": 70, "avg_cpa": 50}
        assert gtm_gen.classify_segment(row) == "high_growth_signal"

    def test_classify_from_why_it_matters(self, gtm_gen):
        row = {"why_it_matters": "High search demand, low provider coverage — recruit providers",
               "demand_score": 0, "supply_gap_score": 0}
        assert gtm_gen.classify_segment(row) == "high_demand_low_supply"

    def test_generate_tests(self, gtm_gen):
        segments = [
            {"specialty": "Dermatology", "city": "Miami", "poi": 82,
             "demand_score": 80, "supply_gap_score": 85, "avg_cpa": 35},
        ]
        tests = gtm_gen.generate_tests(segments)
        assert len(tests) >= 1
        assert tests[0]["ai_generated"] is True
        assert "Dermatology" in tests[0]["segment"]
        assert "Miami" in tests[0]["segment"]

    def test_generate_summary(self, gtm_gen):
        tests = [
            {"name": "Test A", "segment": "Derm - Miami", "strategy": "Recruit",
             "hypothesis": "H1", "duration": "4 weeks", "metric": "bookings"}
        ]
        summary = gtm_gen.generate_summary(tests)
        assert "AI-Generated" in summary
        assert "Test A" in summary

    def test_empty_segments(self, gtm_gen):
        tests = gtm_gen.generate_tests([])
        assert tests == []


# ============================================================================
# TEST: POI Scorer
# ============================================================================

class TestPOIScorer:
    def test_compute_from_views(self, poi_scorer):
        rows = poi_scorer.compute_from_views()
        assert len(rows) > 0
        assert "poi" in rows[0]
        assert "rank" in rows[0]

    def test_poi_scores_are_reasonable(self, poi_scorer):
        rows = poi_scorer.compute_from_views()
        for row in rows:
            # POI should be non-negative
            assert row["poi"] >= 0
            # Rank should be positive integer
            assert row["rank"] >= 1

    def test_top_segment_has_highest_poi(self, poi_scorer):
        rows = poi_scorer.compute_from_views()
        if len(rows) >= 2:
            assert rows[0]["poi"] >= rows[1]["poi"]

    def test_cache_scores(self, poi_scorer):
        count = poi_scorer.cache_scores()
        assert count > 0

    def test_get_top_segments(self, poi_scorer):
        # Must cache first
        poi_scorer.cache_scores()
        top = poi_scorer.get_top_segments(5)
        assert len(top) <= 5
        assert len(top) > 0
        assert "poi" in top[0]


# ============================================================================
# TEST: End-to-End Pipeline
# ============================================================================

class TestEndToEnd:
    def test_full_pipeline_poi(self, db_conn, schema, guardrails):
        """Run a full query through all 4 components."""
        from src.main import DemandEngine

        engine = DemandEngine(db_path=":memory:", verbose=False)
        result = engine.run("top segments by POI")

        assert result.get("error") is None
        assert result["row_count"] > 0
        assert result["validation"]["valid"] is True
        assert result["explanation"] != ""
        assert result["source"] == "template"
        assert result["timing"]["total_ms"] >= 0

    def test_full_pipeline_demand(self, db_conn, schema, guardrails):
        engine = DemandEngine(db_path=":memory:", verbose=False)
        result = engine.run("demand for Dermatology in Miami")

        assert result.get("error") is None
        assert result["row_count"] >= 1

    def test_full_pipeline_gtm(self, db_conn, schema, guardrails):
        engine = DemandEngine(db_path=":memory:", verbose=False)
        result = engine.run("gtm recommendations")

        assert result.get("error") is None
        assert result["row_count"] >= 1
        # GTM tests should be generated for segment results
        assert len(result.get("gtm_tests", [])) >= 1
