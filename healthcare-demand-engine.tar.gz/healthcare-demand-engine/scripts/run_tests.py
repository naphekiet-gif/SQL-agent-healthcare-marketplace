#!/usr/bin/env python3
"""
Standalone Test Runner — no external dependencies required.
Runs all tests using only stdlib + project modules.

Usage: python3 scripts/run_tests.py
"""

import sys
import os
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils.database import init_database, execute_query
from src.utils.config import load_schema_config, load_guardrails_config, get_schema_prompt
from src.agents.sql_query_agent import SQLQueryAgent
from src.validators.schema_validator import SchemaValidator
from src.explainers.result_explainer import ResultExplainer
from src.generators.gtm_test_generator import GTMTestGenerator
from src.models.poi_scorer import POIScorer
from src.monitoring.observability import AgentMonitor


passed = 0
failed = 0
errors = []


def test(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  ✓ {name}")
    else:
        failed += 1
        msg = f"  ✗ {name}"
        if detail:
            msg += f" — {detail}"
        print(msg)
        errors.append(name)


def run_all_tests():
    global passed, failed

    # ---- Setup ----
    print("=" * 65)
    print("HEALTHCARE DEMAND ENGINE — TEST SUITE")
    print("=" * 65)
    print()

    print("Setting up test database (in-memory)...")
    conn = init_database(":memory:")
    schema = load_schema_config()
    guardrails = load_guardrails_config()
    schema_prompt = get_schema_prompt(schema)

    sql_agent = SQLQueryAgent(conn, llm_client=None, schema_prompt=schema_prompt)
    validator = SchemaValidator(conn, guardrails, schema)
    explainer = ResultExplainer(llm_client=None)
    gtm_gen = GTMTestGenerator(llm_client=None)
    poi_scorer = POIScorer(conn)
    monitor = AgentMonitor(conn, log_to_stdout=False)

    print("Setup complete.\n")

    # ==== DATABASE TESTS ====
    print("--- Database Initialization ---")
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    test("geo_markets table exists", "geo_markets" in tables)
    test("providers table exists", "providers" in tables)
    test("search_events table exists", "search_events" in tables)
    test("bookings table exists", "bookings" in tables)
    test("agent_runs table exists", "agent_runs" in tables)
    test("poi_scores table exists", "poi_scores" in tables)

    views = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='view'").fetchall()}
    test("v_demand_signals view exists", "v_demand_signals" in views)
    test("v_supply_metrics view exists", "v_supply_metrics" in views)
    test("v_booking_performance view exists", "v_booking_performance" in views)
    test("v_poi_ranking view exists", "v_poi_ranking" in views)
    test("v_gtm_segments view exists", "v_gtm_segments" in views)

    geo_count = conn.execute("SELECT COUNT(*) FROM geo_markets").fetchone()[0]
    test(f"geo_markets has seed data ({geo_count} rows)", geo_count >= 20)

    prov_count = conn.execute("SELECT COUNT(*) FROM providers").fetchone()[0]
    test(f"providers has seed data ({prov_count} rows)", prov_count >= 30)

    search_count = conn.execute("SELECT COUNT(*) FROM search_events").fetchone()[0]
    test(f"search_events has seed data ({search_count} rows)", search_count >= 50)

    book_count = conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]
    test(f"bookings has seed data ({book_count} rows)", book_count >= 40)

    rows = execute_query(conn, "SELECT * FROM geo_markets", limit=5)
    test("execute_query returns dicts", isinstance(rows[0], dict) and "city" in rows[0])
    print()

    # ==== COMPONENT 1: SQL QUERY AGENT ====
    print("--- Component 1: SQL Query Agent ---")
    r = sql_agent.generate("top segments by POI")
    test("POI template match", r["sql"] is not None and "v_poi_ranking" in r["sql"])
    test("POI source = template", r["source"] == "template")

    r = sql_agent.generate("top search demand by specialty")
    test("Demand template match", r["sql"] is not None and "search_events" in r["sql"])

    r = sql_agent.generate("booking metrics by specialty")
    test("Booking template match", r["sql"] is not None and "v_booking_performance" in r["sql"])

    r = sql_agent.generate("how many providers in Phoenix")
    test("Provider count template match", r["sql"] is not None and "Phoenix" in r["sql"])

    r = sql_agent.generate("gtm recommendations")
    test("GTM template match", r["sql"] is not None and "v_gtm_segments" in r["sql"])

    r = sql_agent.generate("supply demand gap")
    test("Supply-demand gap match", r["sql"] is not None and "v_supply_demand_gap" in r["sql"])

    r = sql_agent.generate("average CPA by specialty")
    test("CPA template match", r["sql"] is not None and "cpa" in r["sql"].lower())

    r = sql_agent.generate("demand for Dermatology in Miami")
    test("Parametric query: Derm+Miami", r["sql"] is not None and "Dermatology" in r["sql"] and "Miami" in r["sql"])

    r = sql_agent.generate("monthly booking trends")
    test("Monthly trends match", r["sql"] is not None and "strftime" in r["sql"])

    r = sql_agent.generate("show all markets")
    test("Show markets match", r["sql"] is not None and "geo_markets" in r["sql"])

    r = sql_agent.generate_and_execute("show all markets")
    test(f"Execute: show markets ({r.get('row_count', 0)} rows)", r.get("row_count", 0) >= 10)

    r = sql_agent.generate("random gibberish question 12345")
    test("No-match → llm_unavailable", r.get("source") in ("llm_unavailable", "llm_error"))

    test("latency_ms tracked", "latency_ms" in r and r["latency_ms"] >= 0)
    print()

    # ==== COMPONENT 2: SCHEMA VALIDATOR ====
    print("--- Component 2: Schema Validator ---")
    v = validator.validate("SELECT * FROM providers LIMIT 10")
    test("Valid SELECT passes", v["valid"] is True)

    v = validator.validate("SELECT * FROM v_poi_ranking LIMIT 10")
    test("Valid view query passes", v["valid"] is True)

    v = validator.validate("SELECT p.specialty, g.city FROM providers p JOIN geo_markets g ON p.geo_id = g.geo_id LIMIT 10")
    test("Valid JOIN passes", v["valid"] is True)

    v = validator.validate("DROP TABLE providers")
    test("Blocks DROP", v["valid"] is False and any("BLOCKED" in e for e in v["errors"]))

    v = validator.validate("DELETE FROM bookings WHERE 1=1")
    test("Blocks DELETE", v["valid"] is False)

    v = validator.validate("INSERT INTO providers VALUES ('x')")
    test("Blocks INSERT", v["valid"] is False)

    v = validator.validate("UPDATE providers SET specialty='x'")
    test("Blocks UPDATE", v["valid"] is False)

    v = validator.validate("SELECT patient_name FROM providers LIMIT 10")
    test("Blocks PII column", v["valid"] is False and any("PII" in e or "BLOCKED" in e for e in v["errors"]))

    v = validator.validate("SELECT * FROM sqlite_master LIMIT 10")
    test("Blocks unauthorized table", v["valid"] is False and any("UNAUTHORIZED" in e for e in v["errors"]))

    v = validator.validate("SELECT * FROM providers")
    test("Auto-adds LIMIT", "LIMIT" in v["sql"].upper() and any("AUTO_LIMIT" in w for w in v["warnings"]))

    v = validator.validate("SELECT * FROM providers LIMIT 50000")
    test("Caps excessive LIMIT", "LIMIT 1000" in v["sql"])

    vr = validator.validate_and_report("SELECT * FROM providers LIMIT 10")
    test("Report contains PASS", "PASS" in vr["report"])
    print()

    # ==== COMPONENT 3: RESULT EXPLAINER ====
    print("--- Component 3: Result Explainer ---")
    r = explainer.explain("test", "SELECT 1", [])
    test("Empty results explanation", "no results" in r["explanation"].lower())
    test("AI disclosure tag", r["ai_generated"] is True)

    mock_poi = [
        {"specialty": "Dermatology", "city": "Miami", "poi": 82, "rank": 1},
        {"specialty": "Cardiology", "city": "Phoenix", "poi": 78, "rank": 2},
        {"specialty": "Pediatrics", "city": "Austin", "poi": 74, "rank": 3},
    ]
    r = explainer.explain("top segments", "SELECT...", mock_poi)
    test("POI explanation mentions top segment", "Dermatology" in r["explanation"])

    mock_demand = [{"specialty": "Dermatology", "search_volume": 150, "avg_ctr": 0.42}]
    r = explainer.explain("search demand", "SELECT...", mock_demand)
    test("Demand explanation mentions volume", "150" in r["explanation"])

    mock_book = [{"specialty": "Cardiology", "total_bookings": 45, "avg_cpa": 55.00, "completion_rate": 0.85}]
    r = explainer.explain("bookings", "SELECT...", mock_book)
    test("Booking explanation mentions specialty", "Cardiology" in r["explanation"])

    mock_cpa = [{"avg_cpa": 350.00}]
    r = explainer.explain("test", "SELECT...", mock_cpa)
    test("Pin check: high CPA flagged", any("High CPA" in c for c in r["pin_checks"]))

    mock_cr = [{"completion_rate": 0.25}]
    r = explainer.explain("test", "SELECT...", mock_cr)
    test("Pin check: low completion flagged", any("low completion" in c.lower() for c in r["pin_checks"]))

    mock_gtm = [{"segment": "Dermatology - Miami", "poi": 82,
                 "why_it_matters": "High search demand, low provider coverage — recruit providers"}]
    r = explainer.explain("gtm", "SELECT...", mock_gtm)
    test("GTM explanation mentions recruit", "recruit" in r["explanation"].lower())
    print()

    # ==== COMPONENT 4: GTM TEST GENERATOR ====
    print("--- Component 4: GTM Test Generator ---")
    row_hd = {"demand_score": 80, "supply_gap_score": 85, "conversion_score": 30, "growth_score": 40, "avg_cpa": 60}
    test("Classify: high demand low supply", gtm_gen.classify_segment(row_hd) == "high_demand_low_supply")

    row_sc = {"demand_score": 50, "supply_gap_score": 40, "conversion_score": 70, "growth_score": 40, "avg_cpa": 35}
    test("Classify: strong conversion", gtm_gen.classify_segment(row_sc) == "strong_conversion_low_cpa")

    row_hg = {"demand_score": 55, "supply_gap_score": 40, "conversion_score": 40, "growth_score": 70, "avg_cpa": 50}
    test("Classify: high growth", gtm_gen.classify_segment(row_hg) == "high_growth_signal")

    row_why = {"why_it_matters": "recruit providers", "demand_score": 0, "supply_gap_score": 0}
    test("Classify from why_it_matters", gtm_gen.classify_segment(row_why) == "high_demand_low_supply")

    segments = [{"specialty": "Dermatology", "city": "Miami", "poi": 82,
                 "demand_score": 80, "supply_gap_score": 85, "avg_cpa": 35}]
    tests_out = gtm_gen.generate_tests(segments)
    test("Generate tests produces results", len(tests_out) >= 1)
    test("Test has ai_generated flag", tests_out[0].get("ai_generated") is True)
    test("Test has segment field", "Dermatology" in tests_out[0].get("segment", ""))

    summary = gtm_gen.generate_summary(tests_out)
    test("Summary contains AI disclosure", "AI-Generated" in summary)

    test("Empty segments → empty tests", gtm_gen.generate_tests([]) == [])
    print()

    # ==== POI SCORER ====
    print("--- POI Scorer ---")
    poi_rows = poi_scorer.compute_from_views()
    test(f"POI compute returns rows ({len(poi_rows)})", len(poi_rows) > 0)
    test("POI rows have 'poi' column", "poi" in poi_rows[0] if poi_rows else False)
    test("POI rows have 'rank' column", "rank" in poi_rows[0] if poi_rows else False)

    if len(poi_rows) >= 2:
        test("Top POI >= second POI", poi_rows[0]["poi"] >= poi_rows[1]["poi"])

    for row in poi_rows:
        if row["poi"] < 0:
            test("POI non-negative", False, f"poi={row['poi']}")
            break
    else:
        test("All POI scores non-negative", True)

    cache_count = poi_scorer.cache_scores()
    test(f"Cache scores writes ({cache_count} rows)", cache_count > 0)

    top = poi_scorer.get_top_segments(5)
    test(f"Get top segments returns ({len(top)} rows)", len(top) > 0 and len(top) <= 5)
    print()

    # ==== MONITORING ====
    print("--- Monitoring / Observability ---")
    run_id = monitor.log_run(
        natural_query="test query",
        generated_sql="SELECT 1",
        validation_pass=True,
        result_row_count=1,
        explanation="Test explanation",
        latency_ms=42,
        accuracy_score=0.95,
        status="success"
    )
    test("Log run returns run_id", run_id is not None and run_id.startswith("run_"))

    log_row = conn.execute("SELECT * FROM agent_runs WHERE run_id=?", (run_id,)).fetchone()
    test("Run logged to agent_runs table", log_row is not None)

    stats = monitor.get_run_stats()
    test("Get run stats works", stats.get("total_runs", 0) >= 1)
    print()

    # ==== END-TO-END PIPELINE ====
    print("--- End-to-End Pipeline ---")
    from src.main import DemandEngine

    engine = DemandEngine(db_path=":memory:", verbose=False)

    result = engine.run("top segments by POI")
    test("E2E: POI query succeeds", result.get("error") is None)
    test("E2E: POI has results", result.get("row_count", 0) > 0)
    test("E2E: POI validation passed", result.get("validation", {}).get("valid") is True)
    test("E2E: POI has explanation", len(result.get("explanation", "")) > 0)
    test("E2E: POI has timing", result.get("timing", {}).get("total_ms", -1) >= 0)

    result = engine.run("demand for Dermatology in Miami")
    test("E2E: Parametric query succeeds", result.get("error") is None)
    test("E2E: Parametric has results", result.get("row_count", 0) >= 1)

    result = engine.run("gtm recommendations")
    test("E2E: GTM query succeeds", result.get("error") is None)
    test("E2E: GTM generates test ideas", len(result.get("gtm_tests", [])) >= 1)

    result = engine.run("monthly booking trends")
    test("E2E: Monthly trends succeeds", result.get("error") is None)

    result = engine.run("supply demand gap")
    test("E2E: Supply-demand gap succeeds", result.get("error") is None and result.get("row_count", 0) > 0)

    poi_result = engine.run_poi_scoring()
    test("E2E: POI scoring runs", poi_result.get("segments_scored", 0) > 0)
    print()

    # ==== SUMMARY ====
    total = passed + failed
    print("=" * 65)
    print(f"RESULTS: {passed}/{total} tests passed ({passed/total*100:.0f}%)")
    if failed > 0:
        print(f"FAILED ({failed}):")
        for e in errors:
            print(f"  ✗ {e}")
    else:
        print("ALL TESTS PASSED ✓")
    print("=" * 65)

    return passed, failed


if __name__ == "__main__":
    p, f = run_all_tests()
    sys.exit(0 if f == 0 else 1)
