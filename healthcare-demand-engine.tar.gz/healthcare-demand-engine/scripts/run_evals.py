#!/usr/bin/env python3
"""
Evaluation Suite
=================
Tests the agent against a gold set of natural-language queries.
Measures: SQL accuracy, validation pass rate, result quality, latency.

Usage:
    python scripts/run_evals.py
    python -m src.main --eval
"""

import sys
import os
import json
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Gold set: NL queries with expected SQL patterns and minimum row counts
EVAL_GOLD_SET = [
    {
        "id": "eval_001",
        "question": "top search demand by specialty",
        "expected_tables": ["search_events"],
        "expected_columns": ["specialty", "search_volume"],
        "min_rows": 3,
        "category": "demand"
    },
    {
        "id": "eval_002",
        "question": "booking metrics by specialty",
        "expected_tables": ["v_booking_performance"],
        "expected_columns": ["specialty", "total_bookings"],
        "min_rows": 3,
        "category": "bookings"
    },
    {
        "id": "eval_003",
        "question": "how many providers in Phoenix",
        "expected_tables": ["providers", "geo_markets"],
        "expected_columns": ["provider_count"],
        "min_rows": 1,
        "category": "supply"
    },
    {
        "id": "eval_004",
        "question": "top segments by POI",
        "expected_tables": ["v_poi_ranking"],
        "expected_columns": ["poi", "rank"],
        "min_rows": 3,
        "category": "poi"
    },
    {
        "id": "eval_005",
        "question": "average CPA by specialty",
        "expected_tables": ["bookings"],
        "expected_columns": ["avg_cpa"],
        "min_rows": 3,
        "category": "bookings"
    },
    {
        "id": "eval_006",
        "question": "demand for Dermatology in Miami",
        "expected_tables": ["search_events"],
        "expected_columns": ["search_volume"],
        "min_rows": 1,
        "category": "demand"
    },
    {
        "id": "eval_007",
        "question": "supply demand gap",
        "expected_tables": ["v_supply_demand_gap"],
        "expected_columns": ["demand_score", "supply_gap_score"],
        "min_rows": 3,
        "category": "gap"
    },
    {
        "id": "eval_008",
        "question": "gtm recommendations",
        "expected_tables": ["v_gtm_segments"],
        "expected_columns": ["segment", "poi", "why_it_matters"],
        "min_rows": 1,
        "category": "gtm"
    },
    {
        "id": "eval_009",
        "question": "monthly booking trends",
        "expected_tables": ["bookings"],
        "expected_columns": ["month", "bookings"],
        "min_rows": 1,
        "category": "bookings"
    },
    {
        "id": "eval_010",
        "question": "poi segment ranking scores",
        "expected_tables": ["v_poi_ranking"],
        "expected_columns": ["poi"],
        "min_rows": 3,
        "category": "poi"
    },
    {
        "id": "eval_011",
        "question": "show all specialties",
        "expected_tables": ["providers"],
        "expected_columns": ["specialty"],
        "min_rows": 3,
        "category": "exploration"
    },
    {
        "id": "eval_012",
        "question": "show all markets",
        "expected_tables": ["geo_markets"],
        "expected_columns": ["city"],
        "min_rows": 10,
        "category": "exploration"
    },
]

# Guardrail tests: queries that should be BLOCKED
GUARDRAIL_TESTS = [
    {
        "id": "guard_001",
        "question_sql": "DROP TABLE providers",
        "should_block": True,
        "reason": "DDL operation"
    },
    {
        "id": "guard_002",
        "question_sql": "SELECT patient_name FROM providers",
        "should_block": True,
        "reason": "PII column access"
    },
    {
        "id": "guard_003",
        "question_sql": "DELETE FROM bookings WHERE 1=1",
        "should_block": True,
        "reason": "Write operation"
    },
    {
        "id": "guard_004",
        "question_sql": "SELECT * FROM sqlite_master",
        "should_block": True,
        "reason": "Unauthorized table"
    },
]


def run_evals(engine=None):
    """Run the full evaluation suite."""
    if engine is None:
        from src.main import DemandEngine
        engine = DemandEngine(verbose=False)

    print("=" * 60)
    print("EVALUATION SUITE — Healthcare Provider Demand Engine")
    print("=" * 60)

    # ---- NL Query Evals ----
    print("\n--- Natural Language Query Tests ---\n")
    passed = 0
    failed = 0
    total_latency = 0

    for eval_case in EVAL_GOLD_SET:
        result = engine.run(eval_case["question"])
        latency = result.get("timing", {}).get("total_ms", 0)
        total_latency += latency

        row_count = result.get("row_count", 0)
        has_error = bool(result.get("error"))
        min_rows = eval_case["min_rows"]

        # Check: no errors
        # Check: has results
        # Check: expected columns present
        results = result.get("results", [])
        result_cols = set()
        if results:
            result_cols = set(results[0].keys())

        expected_cols = set(eval_case["expected_columns"])
        cols_present = expected_cols.issubset(result_cols)

        pass_test = (not has_error) and (row_count >= min_rows) and cols_present

        status = "PASS" if pass_test else "FAIL"
        icon = "✓" if pass_test else "✗"

        if pass_test:
            passed += 1
        else:
            failed += 1

        reason = ""
        if has_error:
            reason = f" — Error: {result.get('error', '')[:60]}"
        elif row_count < min_rows:
            reason = f" — Got {row_count} rows, expected >= {min_rows}"
        elif not cols_present:
            missing = expected_cols - result_cols
            reason = f" — Missing columns: {missing}"

        print(f"  {icon} [{eval_case['id']}] {eval_case['question'][:45]:<45} "
              f"{status:>4}  {latency:>4}ms  rows={row_count}{reason}")

    total = passed + failed
    pct = (passed / total * 100) if total else 0
    avg_latency = total_latency / total if total else 0

    print(f"\n  Results: {passed}/{total} passed ({pct:.0f}%)")
    print(f"  Avg latency: {avg_latency:.0f}ms")

    # ---- Guardrail Tests ----
    print("\n--- Guardrail / Safety Tests ---\n")
    guard_passed = 0

    for gt in GUARDRAIL_TESTS:
        sql = gt["question_sql"]
        validation = engine.validator.validate(sql)
        blocked = not validation["valid"]

        if blocked == gt["should_block"]:
            guard_passed += 1
            icon = "✓"
            status = "BLOCKED" if blocked else "ALLOWED"
        else:
            icon = "✗"
            status = "SHOULD HAVE BLOCKED" if gt["should_block"] else "WRONGLY BLOCKED"

        print(f"  {icon} [{gt['id']}] {sql[:45]:<45} {status:>20} ({gt['reason']})")

    print(f"\n  Guardrails: {guard_passed}/{len(GUARDRAIL_TESTS)} correct")

    # ---- POI Scoring Test ----
    print("\n--- POI Scoring Test ---\n")
    poi_result = engine.run_poi_scoring()
    segments = poi_result.get("top_segments", [])
    print(f"  Segments scored: {poi_result.get('segments_scored', 0)}")
    if segments:
        top = segments[0]
        print(f"  #1 segment: {top.get('specialty', '?')} ({top.get('geo_id', '?')}) "
              f"— POI {top.get('poi', 0)}")
        print(f"  ✓ POI scoring operational")
    else:
        print(f"  ✗ No POI segments generated")

    # ---- Summary ----
    print("\n" + "=" * 60)
    total_tests = total + len(GUARDRAIL_TESTS) + 1
    total_passed = passed + guard_passed + (1 if segments else 0)
    print(f"OVERALL: {total_passed}/{total_tests} tests passed "
          f"({total_passed/total_tests*100:.0f}%)")
    print(f"SQL Accuracy: {pct:.0f}% on gold set")
    print(f"Avg Latency: {avg_latency:.0f}ms")
    print("=" * 60)

    return {
        "nl_passed": passed,
        "nl_total": total,
        "guard_passed": guard_passed,
        "guard_total": len(GUARDRAIL_TESTS),
        "avg_latency_ms": avg_latency,
        "sql_accuracy_pct": pct
    }


if __name__ == "__main__":
    run_evals()
