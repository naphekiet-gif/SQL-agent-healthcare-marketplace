#!/usr/bin/env python3
"""
Initialize the database with schema, views, and seed data.
Run this once before using the agent.

Usage: python scripts/init_database.py
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils.database import init_database, get_table_names, get_view_names, get_row_count


def main():
    print("=" * 50)
    print("Healthcare Provider Demand Engine — DB Init")
    print("=" * 50)

    conn = init_database()

    print("\nTables:")
    for t in get_table_names(conn):
        count = get_row_count(conn, t)
        print(f"  {t}: {count} rows")

    print("\nViews:")
    for v in get_view_names(conn):
        count = get_row_count(conn, v)
        print(f"  {v}: {count} rows")

    print("\nDatabase ready at: data/demand_engine.db")
    conn.close()


if __name__ == "__main__":
    main()
