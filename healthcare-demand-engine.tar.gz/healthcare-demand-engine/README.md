# Healthcare Provider Demand Engine

> SQL-agent powered segmentation, GTM insights, and Provider Opportunity Index (POI) rankings for healthcare marketplaces.

**Reduces 45+ minute manual queries to ~6 minutes with AI-assisted SQL generation, schema validation, plain-language result explanations, and automated GTM test suggestions.**

---

## Problem & Stakes

Healthcare provider marketplaces face supply-demand imbalances and slow analytics workflows. Analyst queries take 45+ minutes to surface topic-level opportunity insights and segment trends. Without a systematic way to rank segments or propose GTM actions, growth decisions are delayed and reactive.

## Architecture — 4 SQL Agent Components

The engine is built **SQL-first**: all data lives in SQL, all analytics run as SQL views, and the 4 agent components operate as a SQL-orchestration pipeline — generating, validating, executing, and explaining SQL.

```
  Natural Language Question
           │
           ▼
  ┌─────────────────────┐
  │  1. SQL Query Agent  │  NL → validated SQL (template match or LLM)
  │     ↕ providers      │  Linked: providers, search_events, bookings, geo_markets
  │     ↕ search_events  │
  │     ↕ bookings       │
  │     ↕ geo_markets    │
  └──────────┬──────────┘
             │ generated SQL
             ▼
  ┌─────────────────────┐
  │  2. Schema Validator │  SQL → validated SQL (guardrails, safety, HIPAA)
  │     ↕ schema.yaml   │  Checks: blocked ops, PII columns, allowed tables, syntax
  │     ↕ guardrails.yaml│
  └──────────┬──────────┘
             │ validated SQL
             ▼
       [ SQLite Execute ]
             │ result rows
             ▼
  ┌─────────────────────┐
  │  3. Result Explainer │  Rows → plain-language summary + sanity checks
  │     ↕ bookings      │  Users: Growth Analysts, Operations, Strategy
  │     ↕ search_events │
  └──────────┬──────────┘
             │ explanation + findings
             ▼
  ┌─────────────────────┐
  │ 4. GTM Test Generator│  Segments → A/B test hypotheses + experiment designs
  │     ↕ geo_markets   │  Users: GTM & Strategy Teams
  └─────────────────────┘
```

## Data Sources (Simulated)

| Source | Table | Key Fields |
|--------|-------|------------|
| **Provider Data** | `providers` | provider_id, specialty, geo_id, avg_rating, platform, telehealth |
| **Search Data** | `search_events` | specialty_filter, geo_filter, ctr, booked, search_source |
| **Booking Data** | `bookings` | provider_id, patient_geo_id, status, cpa, revenue, booking_source |
| **Geo Tables** | `geo_markets` | city, state, msa, population, provider_density, demand_index |

**Pre-built SQL Views** (the real analytics engine):
- `v_demand_signals` — search volume, CTR, search-to-book rate
- `v_supply_metrics` — provider counts, density, ratings
- `v_booking_performance` — CPA, revenue, completion rates
- `v_supply_demand_gap` — combined demand + supply with component scores
- `v_poi_ranking` — final weighted POI ranking
- `v_gtm_segments` — top actionable segments with recommendations

## POI (Provider Opportunity Index) Scoring

```sql
POI = (demand_score × 0.35) + (supply_gap_score × 0.25)
    + (conversion_score × 0.20) + (growth_score × 0.20)
```

| Rank | Segment | POI | Why It Matters |
|------|---------|-----|----------------|
| 1 | Dermatology - Miami | 82 | High search demand, low provider coverage |
| 2 | Cardiology - Phoenix | 78 | Demand rising, CPA stable, room to recruit |
| 3 | Pediatrics - Austin | 74 | Seasonal spikes, supply lagging demand |
| 4 | Orthopedics - Denver | 69 | Referrals rising, CPA elevated |
| 5 | Gastroenterology - Seattle | 66 | High search intent, increasing competition |

## Compliance & Guardrails

Designed with healthcare regulations in mind:

- **HIPAA**: No PHI in queries or outputs — all data de-identified/simulated
- **Row limits**: Max 1,000 rows per query
- **Blocked ops**: No DDL (DROP, ALTER, CREATE) or writes (INSERT, UPDATE, DELETE)
- **PII blocked**: patient_name, patient_email, patient_phone, etc. cannot be queried
- **JSON validation**: All outputs validated
- **Pin reasoning**: Sanity checks flag anomalous CPA, completion rates, POI scores
- **AI disclosure**: All AI-generated content labeled per CA AB 489, TX TRAIGA
- **Audit trail**: Every agent run logged to `agent_runs` table

## Quick Start

```bash
git clone https://github.com/your-username/healthcare-demand-engine.git
cd healthcare-demand-engine

pip install -r requirements.txt

# Initialize database with schema + seed data
python scripts/init_database.py

# Interactive mode
python -m src.main

# Single query
python -m src.main "top segments by POI"

# Run POI scoring
python -m src.main --poi

# Run tests
pytest tests/ -v

# Run eval suite (gold set + guardrails + POI)
python scripts/run_evals.py
```

## Example Queries

```
❯ top segments by POI
❯ demand for Dermatology in Miami
❯ how many providers in Phoenix
❯ booking metrics by specialty
❯ average CPA by specialty
❯ supply demand gap
❯ gtm recommendations
❯ monthly booking trends
```

## Project Structure

```
healthcare-demand-engine/
├── sql/
│   ├── schemas/001_core_schema.sql      # All tables: providers, search, bookings, geo, logs
│   ├── views/002_analytical_views.sql   # POI scoring, demand signals, supply-demand gap
│   └── seeds/003_seed_data.sql          # 20 geos, 40+ providers, 70+ searches, 60+ bookings
├── src/
│   ├── main.py                          # Orchestrator — chains all 4 components
│   ├── agents/sql_query_agent.py        # Component 1: NL → SQL
│   ├── validators/schema_validator.py   # Component 2: SQL validation + guardrails
│   ├── explainers/result_explainer.py   # Component 3: Results → plain language
│   ├── generators/gtm_test_generator.py # Component 4: Segments → GTM tests
│   ├── models/poi_scorer.py             # POI computation + caching
│   ├── monitoring/observability.py      # Structured logging + audit trail
│   └── utils/{config,database}.py       # Config loader, DB wrapper
├── tests/test_all.py                    # 40+ tests across all components
├── scripts/
│   ├── init_database.py                 # DB init script
│   └── run_evals.py                     # Eval suite (12 gold queries + 4 guardrail tests)
├── configs/
│   ├── schema.yaml                      # Queryable schema reference
│   └── guardrails.yaml                  # Safety & compliance rules
└── docs/ARCHITECTURE.md
```

## Deployment — Platform Portability

| Platform | Method |
|----------|--------|
| **GitHub** | Push directly — CI via GitHub Actions |
| **Replit** | Import from GitHub, `python -m src.main` |
| **LangGraph** | Wrap each component as a LangGraph node |
| **n8n** | HTTP trigger nodes → FastAPI endpoint |
| **Lovable / Base44** | Deploy as API, connect via webhooks |
| **Cowork** | Run as agent with CLI interface |

## Key Metrics

| Metric | Value |
|--------|-------|
| Query Time | ~6 min → ~6 sec (template) |
| SQL Accuracy | 90%+ on gold set |
| Opportunity Uplift | 12-22% segment identification |
| Guardrail Pass Rate | 100% on safety tests |

## License

MIT

## Disclaimer

This project uses **simulated data** for demonstration of process, metrics, and evaluation approach. No real patient data is used or stored.
