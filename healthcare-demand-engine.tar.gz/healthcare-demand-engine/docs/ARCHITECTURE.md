# Architecture — Healthcare Provider Demand Engine

## Overview

This is a **SQL-first AI agent** that translates natural-language analytics questions into validated SQL, executes them against a healthcare marketplace database, explains results in plain language, and generates GTM experiment recommendations.

It was designed for teams at healthcare marketplaces (Zocdoc, Headway, etc.) who need to surface supply-demand opportunities without writing raw SQL or waiting 45+ minutes for analyst turnaround.

---

## Pipeline Flow

```
User asks: "What are the top opportunity segments?"
     │
     ▼
┌──────────────────────────────────────────────────────────────────┐
│ 1. SQL QUERY AGENT                                               │
│    • Matches against 12+ NL→SQL templates (regex)                │
│    • Falls back to Claude API for unmatched queries               │
│    • Outputs: raw SQL string                                      │
│    • Linked tables: providers, search_events, bookings, geo_markets│
└───────────────────────┬──────────────────────────────────────────┘
                        │
                        ▼
┌──────────────────────────────────────────────────────────────────┐
│ 2. SCHEMA VALIDATOR                                              │
│    • Checks SQL against guardrails.yaml                          │
│    • Blocks: DROP, DELETE, INSERT, UPDATE, ALTER, CREATE          │
│    • Blocks: PII columns (patient_name, patient_email, etc.)     │
│    • Blocks: unauthorized tables (sqlite_master, etc.)           │
│    • Enforces: LIMIT clause (auto-adds if missing, caps at 1000) │
│    • Validates: syntax via EXPLAIN                               │
│    • Outputs: validated SQL or error list                        │
└───────────────────────┬──────────────────────────────────────────┘
                        │
                        ▼
                  [ SQLite Execute ]
                        │
                        ▼
┌──────────────────────────────────────────────────────────────────┐
│ 3. RESULT EXPLAINER                                              │
│    • Detects result type (POI, demand, bookings, supply, GTM)    │
│    • Generates plain-language summary                            │
│    • Runs pin-reasoning sanity checks:                           │
│      - CPA in $5-$200 range?                                    │
│      - Completion rate 0-100%?                                   │
│      - POI score 0-100?                                         │
│      - Zero providers = recruitment opportunity                  │
│    • Labels all output as AI-generated (compliance)              │
└───────────────────────┬──────────────────────────────────────────┘
                        │
                        ▼
┌──────────────────────────────────────────────────────────────────┐
│ 4. GTM TEST GENERATOR                                            │
│    • Classifies each segment into a playbook:                    │
│      - high_demand_low_supply → Provider Recruitment Blitz       │
│      - strong_conversion_low_cpa → Scale Proven Winners          │
│      - high_growth_signal → Ride the Growth Wave                 │
│      - demand_but_low_completion → Fix the Funnel                │
│      - emerging_opportunity → Explore & Validate                 │
│    • Generates 2 structured A/B test designs per segment         │
│    • Each test: hypothesis, control, variant, metric, duration   │
└──────────────────────────────────────────────────────────────────┘
```

---

## Data Model (SQL Schema)

### Core Tables

| Table | Purpose | Row Count (seed) |
|-------|---------|-----------------|
| `geo_markets` | 20 U.S. metros with population, income, insurance rates | 20 |
| `providers` | Provider profiles: specialty, geo, ratings, platform | 41 |
| `search_events` | Patient search queries with CTR, booking conversion | 64 |
| `bookings` | Appointments with status, CPA, revenue | 51 |
| `agent_runs` | Audit trail for every agent pipeline execution | dynamic |
| `poi_scores` | Cached POI scores per specialty × geo | dynamic |

### Analytical Views (the real engine)

| View | Purpose |
|------|---------|
| `v_demand_signals` | Aggregates search volume, CTR, search→book rate by specialty + geo |
| `v_supply_metrics` | Provider counts, density per 100k, ratings by specialty + geo |
| `v_booking_performance` | Booking volume, CPA, revenue, completion rate by specialty + geo |
| `v_supply_demand_gap` | Joins demand + supply + bookings, computes 4 component scores |
| `v_poi_ranking` | Final weighted POI with RANK() window function |
| `v_gtm_segments` | Top segments filtered to POI ≥ 40, with plain-language recommendations |

### POI Formula

```
POI = (demand_score × 0.35)
    + (supply_gap_score × 0.25)
    + (conversion_score × 0.20)
    + (growth_score × 0.20)
```

Component scores (0-100 each):
- **demand_score**: Search volume normalized by population
- **supply_gap_score**: Inverse of provider density (fewer providers = higher gap)
- **conversion_score**: Search-to-book rate + booking completion rate
- **growth_score**: CTR momentum + new patient booking ratio

---

## Compliance Architecture

### HIPAA Alignment
- **No PHI**: All data is simulated/de-identified. No patient names, DOBs, addresses, SSNs.
- **Minimum Necessary**: Schema validator blocks all PII columns at query time.
- **Audit Trail**: Every agent run logged with timestamp, SQL, results, errors.
- **Encryption**: SQLite WAL mode; production deployments should use encrypted-at-rest.

### State AI Regulations (2026)
- **CA AB 489**: All AI outputs labeled with `ai_generated: true`
- **TX TRAIGA**: AI disclosure embedded in explanation text `[AI-Generated Summary]`
- **CO AI Act**: Architecture supports impact assessments via `agent_runs` audit table

### Guardrails Enforced
- Blocked SQL operations: DROP, DELETE, UPDATE, INSERT, ALTER, CREATE, TRUNCATE, GRANT, REVOKE
- Blocked keywords: password, ssn, social_security, date_of_birth, patient_name, etc.
- Row limit: 1,000 max per query (auto-enforced)
- Syntax validation: Every SQL checked via EXPLAIN before execution

---

## Deployment Patterns

### Standalone CLI
```bash
python -m src.main                    # Interactive REPL
python -m src.main "your question"    # Single query
```

### As a FastAPI Service
```python
from fastapi import FastAPI
from src.main import DemandEngine

app = FastAPI()
engine = DemandEngine()

@app.get("/query")
def query(q: str):
    return engine.run(q)

@app.get("/poi")
def poi():
    return engine.run_poi_scoring()
```

### LangGraph Integration
Each component maps to a LangGraph node:
```
sql_agent_node → validator_node → executor_node → explainer_node → gtm_node
```

### n8n / Webhook Integration
Deploy FastAPI, then create n8n HTTP Request nodes pointing to `/query` and `/poi`.

---

## Monitoring

All queries are logged to `agent_runs` with structured JSON output:

```json
{
  "run_id": "run_a1b2c3d4e5f6",
  "timestamp": "2026-03-26T19:30:00",
  "natural_query": "top segments by POI",
  "generated_sql": "SELECT * FROM v_poi_ranking LIMIT 15",
  "validation_pass": true,
  "result_row_count": 15,
  "latency_ms": 3,
  "accuracy_score": 0.9,
  "status": "success"
}
```

Aggregate stats available via `engine.get_stats()` or `:stats` in the REPL.
