-- ============================================================================
-- Healthcare Provider Demand Engine — Core Schema
-- All 4 data sources: Provider Data, Search Data, Booking Data, Geo Tables
-- ============================================================================
-- HIPAA Note: This schema is designed for de-identified / simulated data only.
-- No PHI/PII columns (no patient names, SSNs, DOBs, addresses).
-- Compliant with minimum-necessary-standard for analytics use cases.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. GEO TABLES — Market geography, population, provider density
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS geo_markets (
    geo_id          TEXT PRIMARY KEY,
    city            TEXT NOT NULL,
    state           TEXT NOT NULL,
    msa             TEXT,                        -- Metropolitan Statistical Area
    region          TEXT,                        -- e.g. Southeast, Pacific
    population      INTEGER NOT NULL DEFAULT 0,
    median_income   INTEGER,
    insurance_rate  REAL,                        -- % of pop with insurance
    demand_index    REAL DEFAULT 0.0,            -- 0-100 composite demand score
    provider_density REAL DEFAULT 0.0,           -- providers per 100k pop
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_geo_state ON geo_markets(state);
CREATE INDEX IF NOT EXISTS idx_geo_msa ON geo_markets(msa);

-- ---------------------------------------------------------------------------
-- 2. PROVIDER DATA — Provider profiles, specialties, locations, insurance
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS providers (
    provider_id     TEXT PRIMARY KEY,
    npi             TEXT UNIQUE,                 -- National Provider Identifier (masked)
    specialty       TEXT NOT NULL,
    sub_specialty   TEXT,
    practice_name   TEXT,
    geo_id          TEXT NOT NULL REFERENCES geo_markets(geo_id),
    accepts_insurance INTEGER DEFAULT 1,         -- boolean
    insurance_types TEXT,                        -- comma-sep: medicaid,medicare,private
    avg_rating      REAL DEFAULT 0.0,
    review_count    INTEGER DEFAULT 0,
    years_experience INTEGER,
    accepting_new   INTEGER DEFAULT 1,           -- boolean: accepting new patients
    telehealth      INTEGER DEFAULT 0,           -- boolean
    platform        TEXT,                        -- e.g. zocdoc, headway, direct
    listing_status  TEXT DEFAULT 'active',       -- active, paused, churned
    onboarded_at    TEXT,
    last_booking_at TEXT,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_prov_specialty ON providers(specialty);
CREATE INDEX IF NOT EXISTS idx_prov_geo ON providers(geo_id);
CREATE INDEX IF NOT EXISTS idx_prov_platform ON providers(platform);
CREATE INDEX IF NOT EXISTS idx_prov_status ON providers(listing_status);

-- ---------------------------------------------------------------------------
-- 3. SEARCH DATA — Patient search queries, filters, click-throughs
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS search_events (
    search_id       TEXT PRIMARY KEY,
    session_id      TEXT,
    query_text      TEXT,                        -- raw NL query (de-identified)
    specialty_filter TEXT,
    geo_filter      TEXT,                        -- city or MSA searched
    insurance_filter TEXT,
    results_count   INTEGER DEFAULT 0,
    clicked         INTEGER DEFAULT 0,           -- boolean: did user click a result
    booked          INTEGER DEFAULT 0,           -- boolean: did search lead to booking
    ctr             REAL DEFAULT 0.0,            -- click-through rate for this SERP
    search_source   TEXT DEFAULT 'organic',      -- organic, paid, referral, direct
    device_type     TEXT,                        -- mobile, desktop, tablet
    searched_at     TEXT NOT NULL,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_search_specialty ON search_events(specialty_filter);
CREATE INDEX IF NOT EXISTS idx_search_geo ON search_events(geo_filter);
CREATE INDEX IF NOT EXISTS idx_search_date ON search_events(searched_at);

-- ---------------------------------------------------------------------------
-- 4. BOOKING DATA — Appointments, cancellations, no-shows
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bookings (
    booking_id      TEXT PRIMARY KEY,
    provider_id     TEXT NOT NULL REFERENCES providers(provider_id),
    patient_geo_id  TEXT REFERENCES geo_markets(geo_id),
    specialty       TEXT NOT NULL,
    booking_type    TEXT DEFAULT 'new_patient',  -- new_patient, follow_up
    visit_type      TEXT DEFAULT 'in_person',    -- in_person, telehealth
    status          TEXT DEFAULT 'completed',    -- completed, cancelled, no_show
    booking_source  TEXT DEFAULT 'marketplace',  -- marketplace, direct, referral
    insurance_used  TEXT,
    cpa             REAL,                        -- cost per acquisition
    revenue         REAL,
    booked_at       TEXT NOT NULL,
    appointment_at  TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_book_provider ON bookings(provider_id);
CREATE INDEX IF NOT EXISTS idx_book_specialty ON bookings(specialty);
CREATE INDEX IF NOT EXISTS idx_book_geo ON bookings(patient_geo_id);
CREATE INDEX IF NOT EXISTS idx_book_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_book_date ON bookings(booked_at);

-- ---------------------------------------------------------------------------
-- 5. AGENT LOG — Observability: every agent run is logged here
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS agent_runs (
    run_id          TEXT PRIMARY KEY,
    natural_query   TEXT NOT NULL,               -- the user's original NL question
    generated_sql   TEXT,                        -- SQL the agent produced
    validation_pass INTEGER DEFAULT 0,           -- boolean: schema validator pass
    validation_errors TEXT,                      -- JSON array of errors if any
    result_row_count INTEGER,
    explanation     TEXT,                        -- plain-language summary
    gtm_suggestions TEXT,                        -- JSON: GTM test ideas
    latency_ms      INTEGER,
    accuracy_score  REAL,                        -- 0-1 self-assessed confidence
    error_reason    TEXT,
    status          TEXT DEFAULT 'success',      -- success, validation_fail, error
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_runs_status ON agent_runs(status);
CREATE INDEX IF NOT EXISTS idx_runs_date ON agent_runs(created_at);

-- ---------------------------------------------------------------------------
-- 6. POI SCORES — Cached segment-level opportunity scores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS poi_scores (
    poi_id          TEXT PRIMARY KEY,
    specialty       TEXT NOT NULL,
    geo_id          TEXT NOT NULL REFERENCES geo_markets(geo_id),
    demand_score    REAL DEFAULT 0.0,            -- 0-100
    supply_gap_score REAL DEFAULT 0.0,           -- 0-100
    conversion_score REAL DEFAULT 0.0,           -- 0-100
    growth_score    REAL DEFAULT 0.0,            -- 0-100
    poi             REAL DEFAULT 0.0,            -- composite POI
    rank            INTEGER,
    why_it_matters  TEXT,
    scored_at       TEXT DEFAULT (datetime('now')),
    UNIQUE(specialty, geo_id)
);

CREATE INDEX IF NOT EXISTS idx_poi_score ON poi_scores(poi DESC);
CREATE INDEX IF NOT EXISTS idx_poi_specialty ON poi_scores(specialty);
