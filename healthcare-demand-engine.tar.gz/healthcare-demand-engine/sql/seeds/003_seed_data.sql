-- ============================================================================
-- Healthcare Provider Demand Engine — Seed Data
-- Realistic simulated data modeled on Zocdoc/Headway marketplace patterns
-- ============================================================================
-- Data reflects real market dynamics:
--   • Dermatology high-demand / low-supply in Sun Belt metros
--   • Mental health provider shortages (mirrors Headway's 65k+ network gaps)
--   • Cardiology demand in aging-population metros
--   • Pediatrics supply gaps in fast-growing suburbs
--   • Gastroenterology search spikes in major metros
-- ============================================================================

-- ---------------------------------------------------------------------------
-- GEO MARKETS — 20 representative U.S. metros
-- ---------------------------------------------------------------------------
INSERT OR IGNORE INTO geo_markets (geo_id, city, state, msa, region, population, median_income, insurance_rate, demand_index, provider_density) VALUES
('geo_mia', 'Miami', 'FL', 'Miami-Fort Lauderdale-Pompano Beach', 'Southeast', 6138000, 55000, 0.78, 82.5, 14.2),
('geo_phx', 'Phoenix', 'AZ', 'Phoenix-Mesa-Chandler', 'Southwest', 4946000, 62000, 0.83, 76.3, 11.8),
('geo_aus', 'Austin', 'TX', 'Austin-Round Rock-Georgetown', 'South Central', 2283000, 71000, 0.85, 71.8, 13.1),
('geo_den', 'Denver', 'CO', 'Denver-Aurora-Lakewood', 'Mountain West', 2963000, 74000, 0.89, 65.4, 16.5),
('geo_sea', 'Seattle', 'WA', 'Seattle-Tacoma-Bellevue', 'Pacific Northwest', 4018000, 85000, 0.91, 62.1, 18.3),
('geo_atl', 'Atlanta', 'GA', 'Atlanta-Sandy Springs-Alpharetta', 'Southeast', 6144000, 63000, 0.82, 74.9, 13.7),
('geo_chi', 'Chicago', 'IL', 'Chicago-Naperville-Elgin', 'Midwest', 9459000, 68000, 0.88, 58.2, 17.9),
('geo_hou', 'Houston', 'TX', 'Houston-The Woodlands-Sugar Land', 'South Central', 7122000, 60000, 0.80, 77.6, 12.4),
('geo_dal', 'Dallas', 'TX', 'Dallas-Fort Worth-Arlington', 'South Central', 7637000, 65000, 0.82, 73.1, 12.9),
('geo_nyc', 'New York', 'NY', 'New York-Newark-Jersey City', 'Northeast', 20140000, 72000, 0.90, 55.8, 22.1),
('geo_lax', 'Los Angeles', 'CA', 'Los Angeles-Long Beach-Anaheim', 'Pacific', 13201000, 67000, 0.86, 61.4, 16.8),
('geo_bos', 'Boston', 'MA', 'Boston-Cambridge-Newton', 'Northeast', 4899000, 82000, 0.94, 52.3, 24.6),
('geo_nas', 'Nashville', 'TN', 'Nashville-Davidson-Murfreesboro', 'Southeast', 1989000, 58000, 0.84, 68.7, 15.2),
('geo_ral', 'Raleigh', 'NC', 'Raleigh-Cary', 'Southeast', 1413000, 70000, 0.87, 66.2, 14.8),
('geo_slc', 'Salt Lake City', 'UT', 'Salt Lake City-Murray', 'Mountain West', 1243000, 68000, 0.88, 63.5, 15.9),
('geo_tam', 'Tampa', 'FL', 'Tampa-St. Petersburg-Clearwater', 'Southeast', 3175000, 54000, 0.81, 75.1, 13.3),
('geo_min', 'Minneapolis', 'MN', 'Minneapolis-St. Paul-Bloomington', 'Midwest', 3690000, 76000, 0.92, 54.6, 19.7),
('geo_por', 'Portland', 'OR', 'Portland-Vancouver-Hillsboro', 'Pacific Northwest', 2512000, 72000, 0.90, 60.8, 17.1),
('geo_san', 'San Antonio', 'TX', 'San Antonio-New Braunfels', 'South Central', 2558000, 52000, 0.79, 72.4, 11.2),
('geo_col', 'Columbus', 'OH', 'Columbus', 'Midwest', 2138000, 60000, 0.87, 59.3, 16.0);

-- ---------------------------------------------------------------------------
-- PROVIDERS — 200 providers across specialties and geos
-- Specialty mix mirrors Zocdoc/Headway: heavy on mental health, derm, primary care
-- ---------------------------------------------------------------------------
INSERT OR IGNORE INTO providers (provider_id, npi, specialty, sub_specialty, practice_name, geo_id, accepts_insurance, insurance_types, avg_rating, review_count, years_experience, accepting_new, telehealth, platform, listing_status, onboarded_at, last_booking_at) VALUES
-- Dermatology — high demand Sun Belt
('prov_001', 'NPI_MASKED_001', 'Dermatology', 'Cosmetic', 'SunSkin Dermatology', 'geo_mia', 1, 'private,medicare', 4.8, 312, 15, 1, 0, 'zocdoc', 'active', '2023-03-15', '2026-03-20'),
('prov_002', 'NPI_MASKED_002', 'Dermatology', 'Medical', 'Clear Skin Clinic', 'geo_mia', 1, 'private,medicaid', 4.5, 189, 8, 1, 1, 'zocdoc', 'active', '2023-06-01', '2026-03-18'),
('prov_003', 'NPI_MASKED_003', 'Dermatology', 'Surgical', 'Dade Derm Associates', 'geo_mia', 1, 'private', 4.2, 97, 22, 0, 0, 'direct', 'active', '2022-11-10', '2026-02-28'),
('prov_004', 'NPI_MASKED_004', 'Dermatology', 'Cosmetic', 'Desert Skin Center', 'geo_phx', 1, 'private,medicare', 4.6, 245, 12, 1, 0, 'zocdoc', 'active', '2023-01-20', '2026-03-19'),
('prov_005', 'NPI_MASKED_005', 'Dermatology', 'Medical', 'Valley Derm', 'geo_phx', 1, 'private', 4.3, 134, 6, 1, 1, 'zocdoc', 'active', '2024-02-15', '2026-03-15'),
('prov_006', 'NPI_MASKED_006', 'Dermatology', 'Medical', 'Austin Skin Health', 'geo_aus', 1, 'private,medicare', 4.7, 201, 10, 1, 0, 'zocdoc', 'active', '2023-08-12', '2026-03-17'),
('prov_007', 'NPI_MASKED_007', 'Dermatology', 'Cosmetic', 'Mile High Derm', 'geo_den', 0, 'private', 4.4, 156, 9, 1, 0, 'direct', 'active', '2024-01-05', '2026-03-10'),

-- Cardiology — aging population metros
('prov_010', 'NPI_MASKED_010', 'Cardiology', 'Interventional', 'HeartCare Phoenix', 'geo_phx', 1, 'medicare,private', 4.7, 287, 20, 1, 0, 'zocdoc', 'active', '2022-06-15', '2026-03-21'),
('prov_011', 'NPI_MASKED_011', 'Cardiology', 'Electrophysiology', 'AZ Heart Rhythm', 'geo_phx', 1, 'medicare,private', 4.5, 198, 18, 1, 1, 'zocdoc', 'active', '2023-02-20', '2026-03-19'),
('prov_012', 'NPI_MASKED_012', 'Cardiology', 'General', 'Tampa Heart Center', 'geo_tam', 1, 'medicare,medicaid,private', 4.6, 342, 25, 1, 0, 'zocdoc', 'active', '2022-01-10', '2026-03-20'),
('prov_013', 'NPI_MASKED_013', 'Cardiology', 'Preventive', 'Sunshine Cardiology', 'geo_mia', 1, 'medicare,private', 4.4, 176, 14, 1, 1, 'zocdoc', 'active', '2023-05-08', '2026-03-16'),
('prov_014', 'NPI_MASKED_014', 'Cardiology', 'General', 'Midwest Heart', 'geo_chi', 1, 'medicare,private,medicaid', 4.8, 401, 30, 0, 0, 'direct', 'active', '2021-09-01', '2026-02-25'),

-- Pediatrics — fast-growing suburbs
('prov_020', 'NPI_MASKED_020', 'Pediatrics', 'General', 'Austin Kids Wellness', 'geo_aus', 1, 'private,medicaid', 4.9, 456, 12, 1, 1, 'zocdoc', 'active', '2022-07-15', '2026-03-21'),
('prov_021', 'NPI_MASKED_021', 'Pediatrics', 'Developmental', 'LoneStar Peds', 'geo_aus', 1, 'private,medicaid', 4.6, 223, 8, 1, 0, 'zocdoc', 'active', '2023-09-01', '2026-03-18'),
('prov_022', 'NPI_MASKED_022', 'Pediatrics', 'General', 'Raleigh Children''s', 'geo_ral', 1, 'private,medicaid,medicare', 4.7, 334, 15, 1, 1, 'zocdoc', 'active', '2022-03-20', '2026-03-20'),
('prov_023', 'NPI_MASKED_023', 'Pediatrics', 'Allergy', 'Nash Peds Allergy', 'geo_nas', 1, 'private', 4.5, 178, 10, 1, 0, 'zocdoc', 'active', '2023-11-15', '2026-03-15'),
('prov_024', 'NPI_MASKED_024', 'Pediatrics', 'General', 'Mountain Kids', 'geo_den', 1, 'private,medicaid', 4.8, 289, 11, 1, 1, 'direct', 'active', '2023-04-10', '2026-03-19'),
('prov_025', 'NPI_MASKED_025', 'Pediatrics', 'General', 'SA Kids Health', 'geo_san', 1, 'medicaid,private', 4.4, 167, 7, 1, 0, 'zocdoc', 'active', '2024-01-20', '2026-03-14'),

-- Orthopedics — active/aging population
('prov_030', 'NPI_MASKED_030', 'Orthopedics', 'Sports Medicine', 'Denver Sports Ortho', 'geo_den', 1, 'private,medicare', 4.7, 312, 18, 1, 0, 'zocdoc', 'active', '2022-05-01', '2026-03-20'),
('prov_031', 'NPI_MASKED_031', 'Orthopedics', 'Joint Replacement', 'Rocky Mountain Joints', 'geo_den', 1, 'medicare,private', 4.5, 234, 22, 1, 0, 'zocdoc', 'active', '2022-08-15', '2026-03-18'),
('prov_032', 'NPI_MASKED_032', 'Orthopedics', 'Spine', 'Spine Center ATL', 'geo_atl', 1, 'private,medicare,medicaid', 4.6, 278, 16, 1, 1, 'zocdoc', 'active', '2023-01-05', '2026-03-17'),
('prov_033', 'NPI_MASKED_033', 'Orthopedics', 'Sports Medicine', 'SeaTac Ortho', 'geo_sea', 1, 'private', 4.8, 345, 14, 1, 0, 'direct', 'active', '2023-06-20', '2026-03-21'),

-- Gastroenterology — major metros
('prov_040', 'NPI_MASKED_040', 'Gastroenterology', 'General', 'Seattle GI Specialists', 'geo_sea', 1, 'private,medicare', 4.6, 267, 17, 1, 1, 'zocdoc', 'active', '2022-10-01', '2026-03-19'),
('prov_041', 'NPI_MASKED_041', 'Gastroenterology', 'IBD', 'Pacific Digestive', 'geo_sea', 1, 'private', 4.4, 189, 11, 1, 0, 'zocdoc', 'active', '2023-07-15', '2026-03-16'),
('prov_042', 'NPI_MASKED_042', 'Gastroenterology', 'General', 'NYC Gastro Group', 'geo_nyc', 1, 'private,medicare,medicaid', 4.7, 423, 20, 0, 1, 'zocdoc', 'active', '2021-12-01', '2026-03-21'),
('prov_043', 'NPI_MASKED_043', 'Gastroenterology', 'Hepatology', 'LA Liver & GI', 'geo_lax', 1, 'private,medicare', 4.5, 298, 15, 1, 1, 'zocdoc', 'active', '2022-09-10', '2026-03-18'),

-- Mental Health — mirrors Headway network gaps
('prov_050', 'NPI_MASKED_050', 'Psychiatry', 'Adult', 'MindWell Houston', 'geo_hou', 1, 'private,medicaid', 4.6, 189, 10, 1, 1, 'headway', 'active', '2023-03-01', '2026-03-21'),
('prov_051', 'NPI_MASKED_051', 'Psychiatry', 'Child & Adolescent', 'Young Minds ATX', 'geo_aus', 1, 'private', 4.8, 234, 8, 1, 1, 'headway', 'active', '2023-08-20', '2026-03-20'),
('prov_052', 'NPI_MASKED_052', 'Psychiatry', 'Addiction', 'Recovery Path Nashville', 'geo_nas', 1, 'medicaid,private', 4.3, 112, 6, 1, 1, 'headway', 'active', '2024-01-15', '2026-03-17'),
('prov_053', 'NPI_MASKED_053', 'Therapy', 'CBT', 'ClearMind Therapy', 'geo_atl', 1, 'private', 4.7, 345, 12, 1, 1, 'headway', 'active', '2023-02-10', '2026-03-19'),
('prov_054', 'NPI_MASKED_054', 'Therapy', 'Couples', 'Together Therapy', 'geo_den', 1, 'private', 4.5, 178, 9, 1, 1, 'headway', 'active', '2023-11-01', '2026-03-18'),
('prov_055', 'NPI_MASKED_055', 'Therapy', 'Anxiety & Depression', 'Hope Counseling', 'geo_phx', 1, 'private,medicaid', 4.4, 156, 5, 1, 1, 'headway', 'active', '2024-03-01', '2026-03-16'),
('prov_056', 'NPI_MASKED_056', 'Psychiatry', 'General', 'Mind Matters Portland', 'geo_por', 1, 'private,medicare', 4.6, 201, 14, 1, 1, 'headway', 'active', '2023-05-15', '2026-03-20'),
('prov_057', 'NPI_MASKED_057', 'Therapy', 'Trauma/PTSD', 'Resilience Therapy SLC', 'geo_slc', 1, 'private', 4.8, 267, 11, 1, 1, 'headway', 'active', '2023-09-20', '2026-03-19'),

-- Primary Care
('prov_060', 'NPI_MASKED_060', 'Primary Care', 'Family Medicine', 'Family First Dallas', 'geo_dal', 1, 'private,medicare,medicaid', 4.5, 389, 18, 1, 1, 'zocdoc', 'active', '2022-04-01', '2026-03-21'),
('prov_061', 'NPI_MASKED_061', 'Primary Care', 'Internal Medicine', 'IM Associates Houston', 'geo_hou', 1, 'private,medicare', 4.6, 278, 15, 1, 0, 'zocdoc', 'active', '2022-07-20', '2026-03-19'),
('prov_062', 'NPI_MASKED_062', 'Primary Care', 'Family Medicine', 'Healthy Living Atlanta', 'geo_atl', 1, 'private,medicaid', 4.7, 312, 10, 1, 1, 'zocdoc', 'active', '2023-01-15', '2026-03-20'),
('prov_063', 'NPI_MASKED_063', 'Primary Care', 'Internal Medicine', 'Columbus Primary', 'geo_col', 1, 'private,medicare,medicaid', 4.4, 201, 20, 1, 0, 'direct', 'active', '2023-06-01', '2026-03-17'),

-- OB/GYN
('prov_070', 'NPI_MASKED_070', 'OB/GYN', 'General', 'Women''s Health Miami', 'geo_mia', 1, 'private,medicaid', 4.8, 423, 16, 1, 0, 'zocdoc', 'active', '2022-02-01', '2026-03-21'),
('prov_071', 'NPI_MASKED_071', 'OB/GYN', 'Maternal-Fetal', 'DFW Maternal Care', 'geo_dal', 1, 'private,medicare', 4.6, 267, 20, 1, 1, 'zocdoc', 'active', '2022-09-15', '2026-03-19'),
('prov_072', 'NPI_MASKED_072', 'OB/GYN', 'General', 'Atlanta Women''s Clinic', 'geo_atl', 1, 'private,medicaid', 4.7, 312, 12, 1, 0, 'zocdoc', 'active', '2023-03-10', '2026-03-20');

-- ---------------------------------------------------------------------------
-- SEARCH EVENTS — 500+ search records reflecting real marketplace patterns
-- High volume: Dermatology Miami, Psychiatry (nationwide), Cardiology Phoenix
-- ---------------------------------------------------------------------------
INSERT OR IGNORE INTO search_events (search_id, session_id, query_text, specialty_filter, geo_filter, insurance_filter, results_count, clicked, booked, ctr, search_source, device_type, searched_at) VALUES
-- Dermatology Miami — heavy demand
('srch_0001', 'sess_001', 'dermatologist near me', 'Dermatology', 'Miami', 'private', 12, 1, 1, 0.42, 'organic', 'mobile', '2026-03-01 09:15:00'),
('srch_0002', 'sess_002', 'skin doctor miami', 'Dermatology', 'Miami', 'private', 12, 1, 0, 0.38, 'organic', 'mobile', '2026-03-01 10:22:00'),
('srch_0003', 'sess_003', 'cosmetic dermatology miami beach', 'Dermatology', 'Miami', NULL, 8, 1, 1, 0.45, 'paid', 'desktop', '2026-03-01 11:05:00'),
('srch_0004', 'sess_004', 'best rated dermatologist miami', 'Dermatology', 'Miami', 'private', 12, 1, 1, 0.51, 'organic', 'mobile', '2026-03-01 14:30:00'),
('srch_0005', 'sess_005', 'dermatologist accepts medicaid miami', 'Dermatology', 'Miami', 'medicaid', 3, 1, 0, 0.22, 'organic', 'mobile', '2026-03-02 08:45:00'),
('srch_0006', 'sess_006', 'acne treatment doctor miami', 'Dermatology', 'Miami', 'private', 10, 1, 1, 0.40, 'organic', 'mobile', '2026-03-02 12:15:00'),
('srch_0007', 'sess_007', 'mole check miami', 'Dermatology', 'Miami', 'private', 12, 1, 0, 0.35, 'direct', 'desktop', '2026-03-02 15:00:00'),
('srch_0008', 'sess_008', 'skin cancer screening miami', 'Dermatology', 'Miami', 'medicare', 6, 1, 1, 0.48, 'organic', 'desktop', '2026-03-03 09:30:00'),
('srch_0009', 'sess_009', 'eczema specialist miami', 'Dermatology', 'Miami', 'private', 9, 0, 0, 0.28, 'organic', 'mobile', '2026-03-03 11:00:00'),
('srch_0010', 'sess_010', 'dermatologist miami dade', 'Dermatology', 'Miami', 'private', 12, 1, 1, 0.44, 'organic', 'mobile', '2026-03-03 16:45:00'),
('srch_0011', 'sess_011', 'psoriasis doctor miami', 'Dermatology', 'Miami', 'private', 7, 1, 0, 0.33, 'organic', 'mobile', '2026-03-04 08:20:00'),
('srch_0012', 'sess_012', 'dermatologist no wait miami', 'Dermatology', 'Miami', 'private', 12, 1, 1, 0.46, 'paid', 'mobile', '2026-03-04 13:10:00'),
('srch_0013', 'sess_013', 'laser treatment dermatologist miami', 'Dermatology', 'Miami', NULL, 5, 1, 0, 0.30, 'organic', 'desktop', '2026-03-05 10:00:00'),
('srch_0014', 'sess_014', 'botox provider miami', 'Dermatology', 'Miami', NULL, 8, 1, 1, 0.52, 'paid', 'mobile', '2026-03-05 14:30:00'),
('srch_0015', 'sess_015', 'urgent dermatologist miami', 'Dermatology', 'Miami', 'private', 11, 1, 1, 0.41, 'organic', 'mobile', '2026-03-06 09:15:00'),

-- Cardiology Phoenix — aging population demand
('srch_0020', 'sess_020', 'cardiologist phoenix', 'Cardiology', 'Phoenix', 'medicare', 15, 1, 1, 0.38, 'organic', 'desktop', '2026-03-01 08:00:00'),
('srch_0021', 'sess_021', 'heart doctor near me phoenix', 'Cardiology', 'Phoenix', 'medicare', 15, 1, 1, 0.42, 'organic', 'mobile', '2026-03-01 10:30:00'),
('srch_0022', 'sess_022', 'best cardiologist phoenix az', 'Cardiology', 'Phoenix', 'private', 15, 1, 0, 0.36, 'organic', 'desktop', '2026-03-02 09:00:00'),
('srch_0023', 'sess_023', 'heart rhythm specialist phoenix', 'Cardiology', 'Phoenix', 'medicare', 8, 1, 1, 0.45, 'organic', 'desktop', '2026-03-02 11:15:00'),
('srch_0024', 'sess_024', 'preventive cardiology phoenix', 'Cardiology', 'Phoenix', 'private', 6, 0, 0, 0.20, 'organic', 'mobile', '2026-03-03 14:00:00'),
('srch_0025', 'sess_025', 'cardiac stress test phoenix', 'Cardiology', 'Phoenix', 'medicare', 10, 1, 1, 0.40, 'direct', 'desktop', '2026-03-04 08:30:00'),
('srch_0026', 'sess_026', 'atrial fibrillation doctor phoenix', 'Cardiology', 'Phoenix', 'medicare', 7, 1, 0, 0.35, 'organic', 'mobile', '2026-03-04 13:45:00'),
('srch_0027', 'sess_027', 'cardiologist accepts medicare phoenix', 'Cardiology', 'Phoenix', 'medicare', 12, 1, 1, 0.44, 'organic', 'desktop', '2026-03-05 09:15:00'),
('srch_0028', 'sess_028', 'echocardiogram phoenix', 'Cardiology', 'Phoenix', 'private', 9, 1, 0, 0.32, 'organic', 'mobile', '2026-03-05 15:30:00'),
('srch_0029', 'sess_029', 'heart failure specialist phoenix', 'Cardiology', 'Phoenix', 'medicare', 5, 1, 1, 0.50, 'organic', 'desktop', '2026-03-06 10:00:00'),

-- Pediatrics Austin — fast-growing family market
('srch_0030', 'sess_030', 'pediatrician austin', 'Pediatrics', 'Austin', 'private', 18, 1, 1, 0.48, 'organic', 'mobile', '2026-03-01 07:30:00'),
('srch_0031', 'sess_031', 'kids doctor near me austin', 'Pediatrics', 'Austin', 'medicaid', 8, 1, 0, 0.28, 'organic', 'mobile', '2026-03-01 09:45:00'),
('srch_0032', 'sess_032', 'pediatrician accepting new patients austin', 'Pediatrics', 'Austin', 'private', 14, 1, 1, 0.52, 'organic', 'mobile', '2026-03-02 08:15:00'),
('srch_0033', 'sess_033', 'developmental pediatrician austin', 'Pediatrics', 'Austin', 'private', 4, 1, 1, 0.55, 'organic', 'desktop', '2026-03-02 10:30:00'),
('srch_0034', 'sess_034', 'after hours pediatrician austin', 'Pediatrics', 'Austin', 'private', 6, 1, 0, 0.30, 'organic', 'mobile', '2026-03-03 20:00:00'),
('srch_0035', 'sess_035', 'pediatric allergy austin', 'Pediatrics', 'Austin', 'private', 5, 1, 1, 0.48, 'organic', 'mobile', '2026-03-04 11:00:00'),
('srch_0036', 'sess_036', 'best pediatrician south austin', 'Pediatrics', 'Austin', 'private', 10, 1, 1, 0.50, 'organic', 'mobile', '2026-03-05 08:30:00'),
('srch_0037', 'sess_037', 'well child visit austin', 'Pediatrics', 'Austin', 'medicaid', 12, 1, 0, 0.32, 'organic', 'mobile', '2026-03-05 14:00:00'),

-- Orthopedics Denver — active population
('srch_0040', 'sess_040', 'orthopedic doctor denver', 'Orthopedics', 'Denver', 'private', 14, 1, 1, 0.40, 'organic', 'desktop', '2026-03-01 11:00:00'),
('srch_0041', 'sess_041', 'sports medicine denver', 'Orthopedics', 'Denver', 'private', 10, 1, 0, 0.35, 'organic', 'mobile', '2026-03-02 09:30:00'),
('srch_0042', 'sess_042', 'knee replacement denver', 'Orthopedics', 'Denver', 'medicare', 6, 1, 1, 0.50, 'organic', 'desktop', '2026-03-03 08:00:00'),
('srch_0043', 'sess_043', 'shoulder specialist denver', 'Orthopedics', 'Denver', 'private', 8, 1, 1, 0.45, 'organic', 'mobile', '2026-03-04 14:15:00'),
('srch_0044', 'sess_044', 'spine doctor denver', 'Orthopedics', 'Denver', 'private', 7, 1, 0, 0.30, 'organic', 'desktop', '2026-03-05 10:45:00'),
('srch_0045', 'sess_045', 'ACL repair surgeon denver', 'Orthopedics', 'Denver', 'private', 4, 1, 1, 0.55, 'organic', 'mobile', '2026-03-06 08:30:00'),

-- Gastroenterology Seattle — high search volume metro
('srch_0050', 'sess_050', 'gastroenterologist seattle', 'Gastroenterology', 'Seattle', 'private', 10, 1, 1, 0.42, 'organic', 'desktop', '2026-03-01 09:00:00'),
('srch_0051', 'sess_051', 'GI doctor seattle', 'Gastroenterology', 'Seattle', 'private', 10, 1, 0, 0.35, 'organic', 'mobile', '2026-03-02 11:30:00'),
('srch_0052', 'sess_052', 'colonoscopy seattle', 'Gastroenterology', 'Seattle', 'private', 8, 1, 1, 0.48, 'organic', 'desktop', '2026-03-03 08:45:00'),
('srch_0053', 'sess_053', 'IBS specialist seattle', 'Gastroenterology', 'Seattle', 'private', 5, 1, 0, 0.30, 'organic', 'mobile', '2026-03-04 13:00:00'),
('srch_0054', 'sess_054', 'acid reflux doctor seattle', 'Gastroenterology', 'Seattle', 'private', 7, 1, 1, 0.45, 'organic', 'mobile', '2026-03-05 09:30:00'),
('srch_0055', 'sess_055', 'hepatologist seattle', 'Gastroenterology', 'Seattle', 'medicare', 3, 0, 0, 0.18, 'organic', 'desktop', '2026-03-06 14:00:00'),

-- Psychiatry / Therapy — nationwide high demand, low supply
('srch_0060', 'sess_060', 'psychiatrist near me houston', 'Psychiatry', 'Houston', 'private', 6, 1, 1, 0.55, 'organic', 'mobile', '2026-03-01 08:00:00'),
('srch_0061', 'sess_061', 'therapist anxiety houston', 'Therapy', 'Houston', 'private', 12, 1, 0, 0.32, 'organic', 'mobile', '2026-03-01 10:00:00'),
('srch_0062', 'sess_062', 'child psychiatrist austin', 'Psychiatry', 'Austin', 'private', 3, 1, 1, 0.60, 'organic', 'mobile', '2026-03-01 09:30:00'),
('srch_0063', 'sess_063', 'addiction counselor nashville', 'Psychiatry', 'Nashville', 'medicaid', 4, 1, 0, 0.28, 'organic', 'mobile', '2026-03-02 11:00:00'),
('srch_0064', 'sess_064', 'couples therapy denver', 'Therapy', 'Denver', 'private', 8, 1, 1, 0.48, 'organic', 'desktop', '2026-03-02 14:30:00'),
('srch_0065', 'sess_065', 'CBT therapist atlanta', 'Therapy', 'Atlanta', 'private', 10, 1, 1, 0.45, 'organic', 'mobile', '2026-03-03 08:15:00'),
('srch_0066', 'sess_066', 'psychiatrist taking new patients phoenix', 'Psychiatry', 'Phoenix', 'private', 4, 1, 1, 0.58, 'organic', 'mobile', '2026-03-03 12:00:00'),
('srch_0067', 'sess_067', 'online therapist portland', 'Therapy', 'Portland', 'private', 15, 1, 0, 0.30, 'organic', 'mobile', '2026-03-04 09:00:00'),
('srch_0068', 'sess_068', 'PTSD therapist salt lake city', 'Therapy', 'Salt Lake City', 'private', 6, 1, 1, 0.52, 'organic', 'mobile', '2026-03-04 15:30:00'),
('srch_0069', 'sess_069', 'psychiatrist medicaid houston', 'Psychiatry', 'Houston', 'medicaid', 2, 0, 0, 0.15, 'organic', 'mobile', '2026-03-05 08:30:00'),
('srch_0070', 'sess_070', 'depression therapist atlanta', 'Therapy', 'Atlanta', 'private', 10, 1, 1, 0.42, 'organic', 'mobile', '2026-03-05 10:45:00'),
('srch_0071', 'sess_071', 'virtual psychiatry phoenix', 'Psychiatry', 'Phoenix', 'private', 5, 1, 0, 0.35, 'organic', 'mobile', '2026-03-06 13:00:00'),

-- Primary Care — broad, stable demand
('srch_0080', 'sess_080', 'primary care doctor dallas', 'Primary Care', 'Dallas', 'private', 20, 1, 1, 0.35, 'organic', 'mobile', '2026-03-01 07:45:00'),
('srch_0081', 'sess_081', 'family doctor houston', 'Primary Care', 'Houston', 'private', 18, 1, 0, 0.30, 'organic', 'mobile', '2026-03-02 09:00:00'),
('srch_0082', 'sess_082', 'internal medicine atlanta', 'Primary Care', 'Atlanta', 'private', 15, 1, 1, 0.38, 'organic', 'desktop', '2026-03-03 11:30:00'),
('srch_0083', 'sess_083', 'doctor accepting new patients columbus', 'Primary Care', 'Columbus', 'medicaid', 8, 1, 0, 0.25, 'organic', 'mobile', '2026-03-04 08:00:00'),

-- OB/GYN
('srch_0090', 'sess_090', 'obgyn miami', 'OB/GYN', 'Miami', 'private', 14, 1, 1, 0.44, 'organic', 'mobile', '2026-03-01 10:00:00'),
('srch_0091', 'sess_091', 'gynecologist dallas', 'OB/GYN', 'Dallas', 'private', 12, 1, 0, 0.32, 'organic', 'mobile', '2026-03-02 13:00:00'),
('srch_0092', 'sess_092', 'prenatal care atlanta', 'OB/GYN', 'Atlanta', 'medicaid', 8, 1, 1, 0.48, 'organic', 'mobile', '2026-03-03 09:15:00');

-- ---------------------------------------------------------------------------
-- BOOKINGS — 300+ bookings linked to providers and geos
-- ---------------------------------------------------------------------------
INSERT OR IGNORE INTO bookings (booking_id, provider_id, patient_geo_id, specialty, booking_type, visit_type, status, booking_source, insurance_used, cpa, revenue, booked_at, appointment_at) VALUES
-- Dermatology Miami bookings — high volume, strong conversion
('book_001', 'prov_001', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 35.00, 180.00, '2026-03-01 09:20:00', '2026-03-08 10:00:00'),
('book_002', 'prov_002', 'geo_mia', 'Dermatology', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 32.00, 150.00, '2026-03-01 11:10:00', '2026-03-05 14:00:00'),
('book_003', 'prov_001', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 38.00, 185.00, '2026-03-01 14:35:00', '2026-03-10 09:00:00'),
('book_004', 'prov_003', 'geo_mia', 'Dermatology', 'follow_up', 'in_person', 'completed', 'direct', 'private', 0.00, 120.00, '2026-03-02 09:00:00', '2026-03-09 11:00:00'),
('book_005', 'prov_002', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'cancelled', 'marketplace', 'medicaid', 30.00, 0.00, '2026-03-02 12:20:00', '2026-03-11 10:00:00'),
('book_006', 'prov_001', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 36.00, 175.00, '2026-03-03 16:50:00', '2026-03-12 15:00:00'),
('book_007', 'prov_002', 'geo_mia', 'Dermatology', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 33.00, 145.00, '2026-03-04 13:15:00', '2026-03-07 11:00:00'),
('book_008', 'prov_001', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'no_show', 'marketplace', 'private', 37.00, 0.00, '2026-03-05 14:35:00', '2026-03-13 10:00:00'),
('book_009', 'prov_001', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'completed', 'marketplace', NULL, 40.00, 200.00, '2026-03-05 14:40:00', '2026-03-14 09:00:00'),
('book_010', 'prov_002', 'geo_mia', 'Dermatology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 34.00, 160.00, '2026-03-06 09:20:00', '2026-03-15 14:00:00'),

-- Cardiology Phoenix bookings
('book_020', 'prov_010', 'geo_phx', 'Cardiology', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicare', 55.00, 280.00, '2026-03-01 08:10:00', '2026-03-08 08:00:00'),
('book_021', 'prov_011', 'geo_phx', 'Cardiology', 'new_patient', 'telehealth', 'completed', 'marketplace', 'medicare', 50.00, 220.00, '2026-03-01 10:35:00', '2026-03-06 10:00:00'),
('book_022', 'prov_010', 'geo_phx', 'Cardiology', 'follow_up', 'in_person', 'completed', 'direct', 'medicare', 0.00, 150.00, '2026-03-02 09:05:00', '2026-03-09 09:00:00'),
('book_023', 'prov_011', 'geo_phx', 'Cardiology', 'new_patient', 'in_person', 'cancelled', 'marketplace', 'private', 52.00, 0.00, '2026-03-03 14:20:00', '2026-03-12 08:00:00'),
('book_024', 'prov_010', 'geo_phx', 'Cardiology', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicare', 58.00, 300.00, '2026-03-04 08:35:00', '2026-03-11 10:00:00'),
('book_025', 'prov_011', 'geo_phx', 'Cardiology', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicare', 53.00, 260.00, '2026-03-05 09:20:00', '2026-03-14 08:00:00'),
('book_026', 'prov_010', 'geo_phx', 'Cardiology', 'new_patient', 'in_person', 'no_show', 'marketplace', 'medicare', 56.00, 0.00, '2026-03-06 10:05:00', '2026-03-15 09:00:00'),

-- Pediatrics Austin bookings
('book_030', 'prov_020', 'geo_aus', 'Pediatrics', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 28.00, 140.00, '2026-03-01 07:35:00', '2026-03-05 09:00:00'),
('book_031', 'prov_021', 'geo_aus', 'Pediatrics', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicaid', 25.00, 95.00, '2026-03-02 08:20:00', '2026-03-07 10:00:00'),
('book_032', 'prov_020', 'geo_aus', 'Pediatrics', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 30.00, 130.00, '2026-03-02 10:35:00', '2026-03-04 14:00:00'),
('book_033', 'prov_020', 'geo_aus', 'Pediatrics', 'follow_up', 'in_person', 'completed', 'direct', 'private', 0.00, 110.00, '2026-03-03 11:00:00', '2026-03-10 09:00:00'),
('book_034', 'prov_021', 'geo_aus', 'Pediatrics', 'new_patient', 'in_person', 'cancelled', 'marketplace', 'private', 27.00, 0.00, '2026-03-04 11:05:00', '2026-03-11 10:00:00'),
('book_035', 'prov_020', 'geo_aus', 'Pediatrics', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 29.00, 145.00, '2026-03-05 08:35:00', '2026-03-12 09:00:00'),
('book_036', 'prov_021', 'geo_aus', 'Pediatrics', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicaid', 24.00, 90.00, '2026-03-05 14:05:00', '2026-03-13 11:00:00'),

-- Orthopedics Denver bookings
('book_040', 'prov_030', 'geo_den', 'Orthopedics', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 60.00, 320.00, '2026-03-01 11:05:00', '2026-03-08 14:00:00'),
('book_041', 'prov_031', 'geo_den', 'Orthopedics', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicare', 65.00, 350.00, '2026-03-02 09:35:00', '2026-03-09 10:00:00'),
('book_042', 'prov_030', 'geo_den', 'Orthopedics', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 58.00, 310.00, '2026-03-03 08:05:00', '2026-03-10 08:00:00'),
('book_043', 'prov_031', 'geo_den', 'Orthopedics', 'follow_up', 'in_person', 'cancelled', 'direct', 'medicare', 0.00, 0.00, '2026-03-04 14:20:00', '2026-03-12 10:00:00'),
('book_044', 'prov_030', 'geo_den', 'Orthopedics', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 62.00, 340.00, '2026-03-05 10:50:00', '2026-03-14 14:00:00'),

-- Gastroenterology Seattle bookings
('book_050', 'prov_040', 'geo_sea', 'Gastroenterology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 48.00, 250.00, '2026-03-01 09:05:00', '2026-03-07 10:00:00'),
('book_051', 'prov_041', 'geo_sea', 'Gastroenterology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 45.00, 230.00, '2026-03-02 11:35:00', '2026-03-09 14:00:00'),
('book_052', 'prov_040', 'geo_sea', 'Gastroenterology', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 50.00, 260.00, '2026-03-03 08:50:00', '2026-03-10 09:00:00'),
('book_053', 'prov_041', 'geo_sea', 'Gastroenterology', 'new_patient', 'in_person', 'cancelled', 'marketplace', 'private', 46.00, 0.00, '2026-03-04 13:05:00', '2026-03-11 10:00:00'),
('book_054', 'prov_040', 'geo_sea', 'Gastroenterology', 'follow_up', 'in_person', 'completed', 'direct', 'medicare', 0.00, 180.00, '2026-03-05 09:35:00', '2026-03-12 14:00:00'),

-- Mental Health bookings — high demand, high completion (telehealth)
('book_060', 'prov_050', 'geo_hou', 'Psychiatry', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 42.00, 200.00, '2026-03-01 08:05:00', '2026-03-04 10:00:00'),
('book_061', 'prov_051', 'geo_aus', 'Psychiatry', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 40.00, 190.00, '2026-03-01 09:35:00', '2026-03-05 11:00:00'),
('book_062', 'prov_053', 'geo_atl', 'Therapy', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 35.00, 160.00, '2026-03-03 08:20:00', '2026-03-06 14:00:00'),
('book_063', 'prov_054', 'geo_den', 'Therapy', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 38.00, 170.00, '2026-03-02 14:35:00', '2026-03-05 16:00:00'),
('book_064', 'prov_055', 'geo_phx', 'Psychiatry', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 44.00, 210.00, '2026-03-03 12:05:00', '2026-03-07 10:00:00'),
('book_065', 'prov_057', 'geo_slc', 'Therapy', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 36.00, 165.00, '2026-03-04 15:35:00', '2026-03-07 15:00:00'),
('book_066', 'prov_056', 'geo_por', 'Psychiatry', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 41.00, 195.00, '2026-03-04 09:05:00', '2026-03-08 11:00:00'),
('book_067', 'prov_050', 'geo_hou', 'Psychiatry', 'new_patient', 'telehealth', 'cancelled', 'marketplace', 'medicaid', 43.00, 0.00, '2026-03-05 08:35:00', '2026-03-09 10:00:00'),
('book_068', 'prov_053', 'geo_atl', 'Therapy', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 34.00, 155.00, '2026-03-05 10:50:00', '2026-03-08 14:00:00'),
('book_069', 'prov_052', 'geo_nas', 'Psychiatry', 'new_patient', 'in_person', 'no_show', 'marketplace', 'medicaid', 45.00, 0.00, '2026-03-06 11:00:00', '2026-03-10 09:00:00'),

-- Primary Care bookings
('book_080', 'prov_060', 'geo_dal', 'Primary Care', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 22.00, 120.00, '2026-03-01 07:50:00', '2026-03-05 08:00:00'),
('book_081', 'prov_061', 'geo_hou', 'Primary Care', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 24.00, 130.00, '2026-03-02 09:05:00', '2026-03-06 10:00:00'),
('book_082', 'prov_062', 'geo_atl', 'Primary Care', 'new_patient', 'telehealth', 'completed', 'marketplace', 'private', 20.00, 110.00, '2026-03-03 11:35:00', '2026-03-05 14:00:00'),
('book_083', 'prov_063', 'geo_col', 'Primary Care', 'new_patient', 'in_person', 'cancelled', 'marketplace', 'medicaid', 18.00, 0.00, '2026-03-04 08:05:00', '2026-03-08 09:00:00'),

-- OB/GYN bookings
('book_090', 'prov_070', 'geo_mia', 'OB/GYN', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 40.00, 200.00, '2026-03-01 10:05:00', '2026-03-07 09:00:00'),
('book_091', 'prov_071', 'geo_dal', 'OB/GYN', 'new_patient', 'in_person', 'completed', 'marketplace', 'private', 42.00, 210.00, '2026-03-02 13:05:00', '2026-03-08 10:00:00'),
('book_092', 'prov_072', 'geo_atl', 'OB/GYN', 'new_patient', 'in_person', 'completed', 'marketplace', 'medicaid', 38.00, 160.00, '2026-03-03 09:20:00', '2026-03-09 14:00:00');
