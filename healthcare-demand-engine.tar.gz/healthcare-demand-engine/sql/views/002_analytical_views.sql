-- ============================================================================
-- Healthcare Provider Demand Engine — Analytical Views & POI Scoring
-- These power the Result Explainer and POI Ranking components
-- ============================================================================

-- ---------------------------------------------------------------------------
-- VIEW: Demand signals by specialty + geo
-- Aggregates search volume, booking volume, and conversion rates
-- ---------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_demand_signals AS
SELECT
    s.specialty_filter                       AS specialty,
    s.geo_filter                             AS geo,
    g.geo_id,
    g.state,
    g.msa,
    g.population,
    COUNT(DISTINCT s.search_id)              AS search_volume,
    SUM(s.clicked)                           AS total_clicks,
    SUM(s.booked)                            AS total_bookings_from_search,
    ROUND(AVG(s.ctr), 4)                     AS avg_ctr,
    CASE WHEN COUNT(s.search_id) > 0
         THEN ROUND(CAST(SUM(s.booked) AS REAL) / COUNT(s.search_id), 4)
         ELSE 0 END                          AS search_to_book_rate
FROM search_events s
LEFT JOIN geo_markets g ON s.geo_filter = g.city
WHERE s.specialty_filter IS NOT NULL
  AND s.geo_filter IS NOT NULL
GROUP BY s.specialty_filter, s.geo_filter, g.geo_id, g.state, g.msa, g.population;

-- ---------------------------------------------------------------------------
-- VIEW: Supply metrics by specialty + geo
-- Provider density, avg ratings, capacity signals
-- ---------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_supply_metrics AS
SELECT
    p.specialty,
    p.geo_id,
    g.city,
    g.state,
    g.population,
    COUNT(DISTINCT p.provider_id)            AS provider_count,
    ROUND(COUNT(DISTINCT p.provider_id) * 100000.0 / NULLIF(g.population, 0), 2)
                                             AS providers_per_100k,
    ROUND(AVG(p.avg_rating), 2)              AS avg_provider_rating,
    SUM(p.accepting_new)                     AS accepting_new_count,
    SUM(p.telehealth)                        AS telehealth_count,
    SUM(CASE WHEN p.listing_status = 'active' THEN 1 ELSE 0 END)
                                             AS active_count,
    SUM(CASE WHEN p.listing_status = 'churned' THEN 1 ELSE 0 END)
                                             AS churned_count
FROM providers p
JOIN geo_markets g ON p.geo_id = g.geo_id
GROUP BY p.specialty, p.geo_id, g.city, g.state, g.population;

-- ---------------------------------------------------------------------------
-- VIEW: Booking performance by specialty + geo
-- Revenue, CPA, completion rates, source mix
-- ---------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_booking_performance AS
SELECT
    b.specialty,
    b.patient_geo_id                         AS geo_id,
    g.city,
    g.state,
    COUNT(DISTINCT b.booking_id)             AS total_bookings,
    SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END)
                                             AS completed,
    SUM(CASE WHEN b.status = 'cancelled' THEN 1 ELSE 0 END)
                                             AS cancelled,
    SUM(CASE WHEN b.status = 'no_show' THEN 1 ELSE 0 END)
                                             AS no_shows,
    ROUND(AVG(b.cpa), 2)                     AS avg_cpa,
    ROUND(SUM(b.revenue), 2)                 AS total_revenue,
    ROUND(AVG(b.revenue), 2)                 AS avg_revenue_per_booking,
    ROUND(
        CAST(SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END) AS REAL)
        / NULLIF(COUNT(b.booking_id), 0), 4
    )                                        AS completion_rate,
    SUM(CASE WHEN b.booking_source = 'marketplace' THEN 1 ELSE 0 END)
                                             AS marketplace_bookings,
    SUM(CASE WHEN b.booking_type = 'new_patient' THEN 1 ELSE 0 END)
                                             AS new_patient_bookings
FROM bookings b
LEFT JOIN geo_markets g ON b.patient_geo_id = g.geo_id
GROUP BY b.specialty, b.patient_geo_id, g.city, g.state;

-- ---------------------------------------------------------------------------
-- VIEW: Supply-demand gap — the core of POI scoring
-- Combines demand signals with supply to find mismatches
-- ---------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_supply_demand_gap AS
SELECT
    d.specialty,
    d.geo_id,
    d.geo                                    AS city,
    d.state,
    d.population,
    d.search_volume,
    d.avg_ctr,
    d.search_to_book_rate,
    COALESCE(s.provider_count, 0)            AS provider_count,
    COALESCE(s.providers_per_100k, 0)        AS providers_per_100k,
    COALESCE(s.accepting_new_count, 0)       AS accepting_new_count,
    COALESCE(bp.avg_cpa, 0)                  AS avg_cpa,
    COALESCE(bp.completion_rate, 0)          AS completion_rate,
    COALESCE(bp.total_revenue, 0)            AS total_revenue,
    -- Demand score: high search volume relative to population = high demand
    ROUND(MIN(100, (d.search_volume * 1.0 / NULLIF(d.population / 10000.0, 0))), 1)
                                             AS demand_score,
    -- Supply gap: fewer providers per capita = bigger gap = higher score
    ROUND(MAX(0, 100 - COALESCE(s.providers_per_100k, 0) * 5), 1)
                                             AS supply_gap_score,
    -- Conversion: higher search-to-book and completion = higher score
    ROUND(COALESCE(d.search_to_book_rate * 200, 0)
        + COALESCE(bp.completion_rate * 50, 0), 1)
                                             AS conversion_score,
    -- Growth: high CTR + new patient bookings signal growth
    ROUND(COALESCE(d.avg_ctr * 100, 0)
        + COALESCE(bp.new_patient_bookings * 1.0
            / NULLIF(bp.total_bookings, 0) * 50, 0), 1)
                                             AS growth_score
FROM v_demand_signals d
LEFT JOIN v_supply_metrics s
    ON d.specialty = s.specialty AND d.geo_id = s.geo_id
LEFT JOIN v_booking_performance bp
    ON d.specialty = bp.specialty AND d.geo_id = bp.geo_id;

-- ---------------------------------------------------------------------------
-- VIEW: Final POI ranking
-- Weighted composite: demand 35%, supply_gap 25%, conversion 20%, growth 20%
-- ---------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_poi_ranking AS
SELECT
    specialty,
    geo_id,
    city,
    state,
    population,
    search_volume,
    provider_count,
    avg_cpa,
    completion_rate,
    demand_score,
    supply_gap_score,
    conversion_score,
    growth_score,
    ROUND(
        (demand_score * 0.35)
      + (supply_gap_score * 0.25)
      + (conversion_score * 0.20)
      + (growth_score * 0.20)
    , 1)                                     AS poi,
    RANK() OVER (ORDER BY
        (demand_score * 0.35)
      + (supply_gap_score * 0.25)
      + (conversion_score * 0.20)
      + (growth_score * 0.20) DESC
    )                                        AS rank
FROM v_supply_demand_gap
ORDER BY poi DESC;

-- ---------------------------------------------------------------------------
-- VIEW: Top segments for GTM — filtered to actionable opportunities
-- ---------------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS v_gtm_segments AS
SELECT
    rank,
    specialty || ' - ' || city               AS segment,
    poi,
    search_volume,
    provider_count,
    avg_cpa,
    completion_rate,
    CASE
        WHEN supply_gap_score > 70 AND demand_score > 60
            THEN 'High search demand, low provider coverage — recruit providers'
        WHEN conversion_score > 60 AND avg_cpa < 50
            THEN 'Strong conversion, manageable CPA — scale spend'
        WHEN growth_score > 60 AND demand_score > 50
            THEN 'High search intent, rising bookings — invest in visibility'
        WHEN demand_score > 70 AND completion_rate < 0.6
            THEN 'Demand exists but completion low — improve patient experience'
        ELSE 'Monitor — emerging opportunity'
    END AS why_it_matters
FROM v_poi_ranking
WHERE poi >= 40
ORDER BY poi DESC
LIMIT 25;
