"""
Healthcare Provider Demand Engine — Main Orchestrator
======================================================
Pipeline: NL Question → SQL Agent → Schema Validator → Execute → Explainer → GTM Generator

Usage:
    python -m src.main                          # Interactive REPL
    python -m src.main "top segments by POI"    # Single query
    python -m src.main --poi                    # Run POI scoring
    python -m src.main --eval                   # Run eval suite
"""

import sys
import os
import time
import json

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.utils.database import init_database, execute_query
from src.utils.config import load_schema_config, load_guardrails_config, get_schema_prompt
from src.agents.sql_query_agent import SQLQueryAgent
from src.validators.schema_validator import SchemaValidator
from src.explainers.result_explainer import ResultExplainer
from src.generators.gtm_test_generator import GTMTestGenerator
from src.models.poi_scorer import POIScorer
from src.monitoring.observability import AgentMonitor, PipelineTimer


def create_llm_client():
    """Try to create an Anthropic client. Returns None if no API key."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    try:
        import anthropic
        return anthropic.Anthropic(api_key=api_key)
    except ImportError:
        print("[WARN] anthropic package not installed. Running in template-only mode.")
        return None


class DemandEngine:
    """
    Main orchestrator. Chains the 4 components:
      1. SQL Query Agent (NL → SQL)
      2. Schema Validator (SQL → validated SQL)
      3. Result Explainer (results → plain-language)
      4. GTM Test Generator (segments → test ideas)
    """

    def __init__(self, db_path: str = None, verbose: bool = True):
        self.verbose = verbose

        # Initialize database
        if verbose:
            print("Initializing Healthcare Provider Demand Engine...")
        self.conn = init_database(db_path)

        # Load configs
        self.schema = load_schema_config()
        self.guardrails = load_guardrails_config()
        schema_prompt = get_schema_prompt(self.schema)

        # LLM client (optional)
        llm = create_llm_client()
        if llm and verbose:
            print("  [OK] LLM client connected (Claude API)")
        elif verbose:
            print("  [INFO] No ANTHROPIC_API_KEY — running in template mode")

        # Initialize components
        self.sql_agent = SQLQueryAgent(self.conn, llm_client=llm, schema_prompt=schema_prompt)
        self.validator = SchemaValidator(self.conn, self.guardrails, self.schema)
        self.explainer = ResultExplainer(llm_client=llm)
        self.gtm_generator = GTMTestGenerator(llm_client=llm)
        self.poi_scorer = POIScorer(self.conn)
        self.monitor = AgentMonitor(self.conn, log_to_stdout=verbose)

        if verbose:
            print("  [OK] All 4 components initialized")
            print("  [OK] Monitoring active")
            print()

    def run(self, question: str) -> dict:
        """
        Full pipeline: question → SQL → validate → execute → explain → GTM.
        Returns a complete result dict.
        """
        timer = PipelineTimer()

        # Stage 1: SQL Query Agent
        timer.start("sql_generation")
        agent_result = self.sql_agent.generate(question)
        timer.stop()

        sql = agent_result.get("sql")
        if not sql:
            self.monitor.log_run(
                natural_query=question,
                status="error",
                error_reason=agent_result.get("error", "No SQL generated"),
                latency_ms=timer.total_ms
            )
            return {
                "question": question,
                "error": agent_result.get("error", "Could not generate SQL"),
                "suggestion": "Try rephrasing or use a more specific query like "
                              "'top segments by POI' or 'demand for Dermatology in Miami'"
            }

        # Stage 2: Schema Validator
        timer.start("validation")
        validation = self.validator.validate_and_report(sql)
        timer.stop()

        if not validation["valid"]:
            self.monitor.log_run(
                natural_query=question,
                generated_sql=sql,
                validation_pass=False,
                validation_errors=validation["errors"],
                status="validation_fail",
                latency_ms=timer.total_ms
            )
            return {
                "question": question,
                "sql": sql,
                "validation": validation,
                "error": "SQL failed validation",
                "details": validation["errors"]
            }

        validated_sql = validation["sql"]

        # Stage 3: Execute SQL
        timer.start("execution")
        try:
            results = execute_query(self.conn, validated_sql)
        except Exception as e:
            timer.stop()
            self.monitor.log_run(
                natural_query=question,
                generated_sql=validated_sql,
                validation_pass=True,
                status="error",
                error_reason=str(e),
                latency_ms=timer.total_ms
            )
            return {
                "question": question,
                "sql": validated_sql,
                "error": f"Execution error: {str(e)}"
            }
        timer.stop()

        # Stage 4: Result Explainer
        timer.start("explanation")
        explanation_result = self.explainer.explain(
            question=question,
            sql=validated_sql,
            results=results,
            description=agent_result.get("description", "")
        )
        timer.stop()

        # Stage 5: GTM Test Generator (if results look like segments)
        timer.start("gtm_generation")
        gtm_tests = []
        gtm_summary = ""
        if results and any(k in results[0] for k in ["poi", "why_it_matters", "demand_score"]):
            gtm_tests = self.gtm_generator.generate_tests(results[:5])
            gtm_summary = self.gtm_generator.generate_summary(gtm_tests)
        timer.stop()

        # Log the run
        run_id = self.monitor.log_run(
            natural_query=question,
            generated_sql=validated_sql,
            validation_pass=True,
            result_row_count=len(results),
            explanation=explanation_result.get("explanation", ""),
            gtm_suggestions=gtm_tests,
            latency_ms=timer.total_ms,
            accuracy_score=0.9 if agent_result.get("source") == "template" else 0.75,
            status="success"
        )

        return {
            "run_id": run_id,
            "question": question,
            "sql": validated_sql,
            "source": agent_result.get("source", "unknown"),
            "validation": {"valid": True, "warnings": validation.get("warnings", [])},
            "results": results,
            "row_count": len(results),
            "explanation": explanation_result.get("explanation", ""),
            "key_findings": explanation_result.get("key_findings", []),
            "pin_checks": explanation_result.get("pin_checks", []),
            "gtm_tests": gtm_tests,
            "gtm_summary": gtm_summary,
            "timing": timer.to_dict(),
            "ai_generated": True
        }

    def run_poi_scoring(self) -> dict:
        """Compute and cache POI scores, return top segments."""
        count = self.poi_scorer.cache_scores()
        top = self.poi_scorer.get_top_segments(10)
        return {
            "segments_scored": count,
            "top_segments": top,
            "ai_generated": True
        }

    def get_stats(self) -> dict:
        """Get monitoring stats."""
        return self.monitor.get_run_stats()


def print_result(result: dict):
    """Pretty-print a pipeline result to the terminal."""
    print("=" * 70)

    if result.get("error"):
        print(f"ERROR: {result['error']}")
        if result.get("details"):
            for d in result["details"]:
                print(f"  • {d}")
        if result.get("suggestion"):
            print(f"\nSuggestion: {result['suggestion']}")
        print("=" * 70)
        return

    print(f"Question: {result.get('question', '')}")
    print(f"Source:   {result.get('source', '?')}")
    print(f"Timing:   {result.get('timing', {})}")
    print("-" * 70)
    print(f"SQL:\n  {result.get('sql', 'N/A')}")
    print("-" * 70)

    results = result.get("results", [])
    if results:
        # Print as a simple table
        cols = list(results[0].keys())
        # Truncate wide columns
        header = " | ".join(c[:15] for c in cols)
        print(header)
        print("-" * len(header))
        for row in results[:10]:
            vals = []
            for c in cols:
                v = row.get(c, "")
                s = str(v)[:15] if v is not None else "NULL"
                vals.append(s)
            print(" | ".join(vals))
        if len(results) > 10:
            print(f"  ... {len(results) - 10} more rows")
    print("-" * 70)

    explanation = result.get("explanation", "")
    if explanation:
        print("EXPLANATION:")
        print(explanation)
    print("-" * 70)

    gtm_summary = result.get("gtm_summary", "")
    if gtm_summary:
        print("GTM RECOMMENDATIONS:")
        print(gtm_summary)

    pin_checks = result.get("pin_checks", [])
    if pin_checks:
        print("SANITY CHECKS:")
        for pc in pin_checks:
            print(f"  ⚠ {pc}")

    print("=" * 70)
    print()


def interactive_repl(engine: DemandEngine):
    """Run an interactive REPL for querying the engine."""
    print("Healthcare Provider Demand Engine — Interactive Mode")
    print("Type a question in plain English, or one of:")
    print("  :poi     — Run POI scoring")
    print("  :stats   — View monitoring stats")
    print("  :help    — Show example queries")
    print("  :quit    — Exit")
    print()

    examples = [
        "top segments by POI",
        "demand for Dermatology in Miami",
        "how many providers in Phoenix",
        "booking metrics by specialty",
        "average CPA by specialty",
        "supply demand gap",
        "gtm recommendations",
        "monthly booking trends",
        "show all specialties",
        "show all markets",
    ]

    while True:
        try:
            question = input("❯ ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not question:
            continue
        if question in (":quit", ":q", ":exit"):
            print("Goodbye!")
            break
        if question == ":help":
            print("Example queries:")
            for ex in examples:
                print(f"  • {ex}")
            print()
            continue
        if question == ":poi":
            result = engine.run_poi_scoring()
            print(f"\nScored {result['segments_scored']} segments.")
            print("Top segments:")
            for seg in result["top_segments"][:5]:
                print(f"  {seg.get('rank', '?')}. {seg.get('specialty', '?')} "
                      f"({seg.get('geo_id', '?')}) — POI {seg.get('poi', 0)}")
            print()
            continue
        if question == ":stats":
            stats = engine.get_stats()
            print(f"\nAgent Stats: {json.dumps(stats, indent=2)}\n")
            continue

        result = engine.run(question)
        print_result(result)


def main():
    args = sys.argv[1:]

    engine = DemandEngine(verbose=True)

    if not args:
        interactive_repl(engine)
    elif args[0] == "--poi":
        result = engine.run_poi_scoring()
        print(json.dumps(result, indent=2, default=str))
    elif args[0] == "--eval":
        # Run eval suite
        from scripts.run_evals import run_evals
        run_evals(engine)
    elif args[0] == "--stats":
        print(json.dumps(engine.get_stats(), indent=2))
    else:
        question = " ".join(args)
        result = engine.run(question)
        print_result(result)


if __name__ == "__main__":
    main()
