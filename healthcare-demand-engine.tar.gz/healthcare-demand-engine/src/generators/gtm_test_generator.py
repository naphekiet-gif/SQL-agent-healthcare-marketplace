"""
Component 4: GTM Test Generator
=================================
Generates go-to-market test ideas (A/B tests, campaigns, experiments)
based on POI segment rankings and supply-demand gap analysis.

Linked data models: geo_markets (for market context)

Users: GTM & Strategy Teams
"""

from typing import Optional


# Pre-built GTM playbooks keyed by segment signal type
GTM_PLAYBOOKS = {
    "high_demand_low_supply": {
        "strategy": "Provider Recruitment Blitz",
        "tests": [
            {
                "name": "Targeted Provider Outreach",
                "hypothesis": "Recruiting {n_target} new providers in {specialty} / {geo} "
                              "will reduce average wait time and increase booking conversion by 15-20%.",
                "control": "Current provider density and organic acquisition",
                "variant": "Outbound recruitment campaign targeting {specialty} providers "
                           "within 50-mile radius via LinkedIn, medical society partnerships, and referral bonuses",
                "metric": "New provider sign-ups, time-to-first-booking, patient booking conversion rate",
                "duration": "8 weeks",
                "segment": "{specialty} - {geo}"
            },
            {
                "name": "Telehealth Expansion Test",
                "hypothesis": "Adding telehealth-enabled providers to {geo} for {specialty} "
                              "will capture 10-15% of currently unserved demand.",
                "control": "In-person only provider listings",
                "variant": "Promote telehealth badge and virtual-first scheduling for {specialty} in {geo}",
                "metric": "Telehealth booking rate, search-to-book conversion, patient geo radius",
                "duration": "6 weeks",
                "segment": "{specialty} - {geo}"
            }
        ]
    },
    "strong_conversion_low_cpa": {
        "strategy": "Scale Proven Winners",
        "tests": [
            {
                "name": "Paid Search Spend Increase",
                "hypothesis": "Increasing paid search budget by 40% for {specialty} in {geo} "
                              "will maintain CPA below ${cpa_threshold} while growing bookings 25%+.",
                "control": "Current paid search budget allocation",
                "variant": "1.4x budget on branded and specialty-specific keywords in {geo}",
                "metric": "Incremental bookings, CPA, ROAS, impression share",
                "duration": "4 weeks",
                "segment": "{specialty} - {geo}"
            },
            {
                "name": "Referral Program Launch",
                "hypothesis": "A patient referral program in {geo} for {specialty} will generate "
                              "new bookings at 30% lower CPA than paid channels.",
                "control": "No referral incentive (organic word-of-mouth)",
                "variant": "$25 credit for referring patient, $25 for new patient booking",
                "metric": "Referral bookings, referral CPA, LTV of referred patients",
                "duration": "6 weeks",
                "segment": "{specialty} - {geo}"
            }
        ]
    },
    "high_growth_signal": {
        "strategy": "Ride the Growth Wave",
        "tests": [
            {
                "name": "SEO Content Sprint",
                "hypothesis": "Publishing 10 condition-specific landing pages for {specialty} in {geo} "
                              "will increase organic search impressions by 50% within 12 weeks.",
                "control": "Current organic landing pages",
                "variant": "New condition-specific pages (e.g., '{specialty} for [condition]' in {geo}) "
                           "with provider spotlights and insurance info",
                "metric": "Organic impressions, CTR, organic bookings, keyword rankings",
                "duration": "12 weeks",
                "segment": "{specialty} - {geo}"
            },
            {
                "name": "Provider Profile Enhancement",
                "hypothesis": "Enriching provider profiles with video intros and insurance verification badges "
                              "will increase CTR by 20% for {specialty} in {geo}.",
                "control": "Standard provider profiles (text + photo + reviews)",
                "variant": "Enhanced profiles with 60-sec video, verified insurance badge, next-available slot",
                "metric": "Profile CTR, search-to-book rate, time-on-profile",
                "duration": "6 weeks",
                "segment": "{specialty} - {geo}"
            }
        ]
    },
    "demand_but_low_completion": {
        "strategy": "Fix the Funnel",
        "tests": [
            {
                "name": "Appointment Reminder Optimization",
                "hypothesis": "Adding SMS + email reminders at 48h, 24h, and 2h before appointments "
                              "will reduce no-shows by 30% for {specialty} in {geo}.",
                "control": "Single email reminder 24h before",
                "variant": "Multi-channel (SMS + email) at 48h, 24h, and 2h with one-tap confirm/reschedule",
                "metric": "No-show rate, cancellation rate, rebooking rate",
                "duration": "4 weeks",
                "segment": "{specialty} - {geo}"
            },
            {
                "name": "Insurance Pre-Verification",
                "hypothesis": "Pre-verifying insurance coverage before booking confirmation will "
                              "reduce cancellations by 20% for {specialty} in {geo}.",
                "control": "Insurance verified at check-in (current flow)",
                "variant": "Real-time insurance eligibility check during booking flow",
                "metric": "Cancellation rate, booking completion rate, patient satisfaction",
                "duration": "6 weeks",
                "segment": "{specialty} - {geo}"
            }
        ]
    },
    "emerging_opportunity": {
        "strategy": "Explore & Validate",
        "tests": [
            {
                "name": "Demand Validation Survey",
                "hypothesis": "Running targeted ads to {geo} residents for {specialty} "
                              "will validate demand at <$2 per survey response.",
                "control": "No active demand measurement",
                "variant": "Geo-targeted social ads → landing page → 3-question demand survey",
                "metric": "Survey responses, stated intent to book, insurance type distribution",
                "duration": "3 weeks",
                "segment": "{specialty} - {geo}"
            }
        ]
    }
}


class GTMTestGenerator:
    """
    Generates structured GTM test recommendations based on
    POI segment data and supply-demand signals.
    """

    def __init__(self, llm_client=None):
        self.llm_client = llm_client

    def classify_segment(self, row: dict) -> str:
        """Classify a segment row into a GTM playbook type."""
        demand = row.get("demand_score", 0) or 0
        supply_gap = row.get("supply_gap_score", 0) or 0
        conversion = row.get("conversion_score", 0) or 0
        growth = row.get("growth_score", 0) or 0
        completion = row.get("completion_rate", 0) or 0
        cpa = row.get("avg_cpa", 999) or 999

        # Also handle the v_gtm_segments view which has why_it_matters
        why = row.get("why_it_matters", "")
        if "recruit" in why.lower():
            return "high_demand_low_supply"
        if "scale spend" in why.lower():
            return "strong_conversion_low_cpa"
        if "visibility" in why.lower():
            return "high_growth_signal"
        if "experience" in why.lower():
            return "demand_but_low_completion"

        # Score-based classification
        if supply_gap > 70 and demand > 60:
            return "high_demand_low_supply"
        if conversion > 60 and cpa < 50:
            return "strong_conversion_low_cpa"
        if growth > 60 and demand > 50:
            return "high_growth_signal"
        if demand > 70 and completion < 0.6:
            return "demand_but_low_completion"
        return "emerging_opportunity"

    def generate_tests(self, segments: list[dict]) -> list[dict]:
        """
        Generate GTM test recommendations for a list of POI segments.
        Returns a list of test objects with all fields populated.
        """
        all_tests = []

        for segment_row in segments:
            specialty = segment_row.get("specialty", "Unknown")
            geo = segment_row.get("city") or segment_row.get("geo", "Unknown")
            poi = segment_row.get("poi", 0)
            cpa = segment_row.get("avg_cpa", 50)

            # Parse segment field if it exists (from v_gtm_segments)
            seg_str = segment_row.get("segment", "")
            if " - " in seg_str:
                parts = seg_str.split(" - ", 1)
                specialty = parts[0]
                geo = parts[1]

            # Classify and get playbook
            playbook_key = self.classify_segment(segment_row)
            playbook = GTM_PLAYBOOKS.get(playbook_key, GTM_PLAYBOOKS["emerging_opportunity"])

            # Fill in templates
            for test_template in playbook["tests"]:
                test = {}
                for key, val in test_template.items():
                    if isinstance(val, str):
                        test[key] = val.format(
                            specialty=specialty,
                            geo=geo,
                            n_target=max(5, int(poi / 5)),
                            cpa_threshold=round(cpa * 1.2, 2) if cpa else 60
                        )
                    else:
                        test[key] = val

                test["poi"] = poi
                test["strategy"] = playbook["strategy"]
                test["playbook"] = playbook_key
                test["ai_generated"] = True
                all_tests.append(test)

        return all_tests

    def generate_summary(self, tests: list[dict]) -> str:
        """Generate a summary of all GTM tests."""
        if not tests:
            return "[AI-Generated] No GTM tests generated — no qualifying segments found."

        lines = [
            "[AI-Generated] GTM Test Recommendations",
            f"Generated {len(tests)} test ideas across {len(set(t['segment'] for t in tests))} segments.",
            ""
        ]

        by_strategy = {}
        for t in tests:
            strat = t.get("strategy", "Other")
            by_strategy.setdefault(strat, []).append(t)

        for strategy, stests in by_strategy.items():
            lines.append(f"Strategy: {strategy}")
            for t in stests:
                lines.append(f"  • {t['name']} ({t['segment']})")
                lines.append(f"    Hypothesis: {t['hypothesis'][:120]}...")
                lines.append(f"    Duration: {t['duration']} | Metric: {t['metric'][:60]}")
            lines.append("")

        return "\n".join(lines)
