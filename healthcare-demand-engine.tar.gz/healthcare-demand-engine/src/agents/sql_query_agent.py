"""
Component 1: SQL Query Agent
=============================
Translates natural-language questions into validated SQL queries
against the healthcare demand engine schema.

Linked data models: providers, search_events, bookings, geo_markets

Supports two modes:
  1. LLM-powered (uses Anthropic Claude API for NL→SQL)
  2. Template-based (rule-matching fallback — no API key needed)
"""

import re
import time
from typing import Optional

# Template-based NL→SQL patterns for common healthcare analytics queries
QUERY_TEMPLATES = {
    # ---- Demand / Search patterns ----
    r"(?i)top\s+(?:search\s+)?(?:demand|search)\s+(?:by\s+)?(?:specialty|specialties)": {
        "sql": """
            SELECT specialty_filter AS specialty,
                   COUNT(*) AS search_volume,
                   ROUND(AVG(ctr), 3) AS avg_ctr,
                   SUM(booked) AS bookings_from_search
            FROM search_events
            WHERE specialty_filter IS NOT NULL
            GROUP BY specialty_filter
            ORDER BY search_volume DESC
            LIMIT 10
        """,
        "description": "Top specialties by search demand"
    },

    r"(?i)(?:search|demand)\s+(?:metrics|data)\s+(?:by|for)\s+(?:specialty|spec)\s+(?:and|&)\s+(?:geo|geography|market|city)": {
        "sql": "SELECT * FROM v_demand_signals ORDER BY search_volume DESC LIMIT 20",
        "description": "Demand signals by specialty and geography"
    },

    r"(?i)(?:search|demand)\s+(?:for|in)\s+(\w[\w\s]*?)\s+(?:in|near|around)\s+(\w[\w\s]*)": {
        "sql_template": """
            SELECT specialty_filter AS specialty, geo_filter AS city,
                   COUNT(*) AS search_volume,
                   ROUND(AVG(ctr), 3) AS avg_ctr,
                   SUM(booked) AS bookings
            FROM search_events
            WHERE specialty_filter LIKE '%{specialty}%'
              AND geo_filter LIKE '%{geo}%'
            GROUP BY specialty_filter, geo_filter
            LIMIT 20
        """,
        "params": ["specialty", "geo"],
        "description": "Search demand for {specialty} in {geo}"
    },

    # ---- Supply / Provider patterns ----
    r"(?i)(?:provider|supply)\s+(?:count|density|metrics)\s+(?:by|for)\s+(?:specialty|spec)": {
        "sql": "SELECT * FROM v_supply_metrics ORDER BY provider_count DESC LIMIT 20",
        "description": "Supply metrics by specialty and geography"
    },

    r"(?i)(?:how many|count)\s+(?:providers?|doctors?)\s+(?:in|for)\s+(\w[\w\s]*)": {
        "sql_template": """
            SELECT p.specialty, g.city, g.state,
                   COUNT(*) AS provider_count,
                   SUM(p.accepting_new) AS accepting_new,
                   ROUND(AVG(p.avg_rating), 2) AS avg_rating
            FROM providers p
            JOIN geo_markets g ON p.geo_id = g.geo_id
            WHERE (p.specialty LIKE '%{term}%' OR g.city LIKE '%{term}%')
              AND p.listing_status = 'active'
            GROUP BY p.specialty, g.city, g.state
            ORDER BY provider_count DESC
            LIMIT 20
        """,
        "params": ["term"],
        "description": "Provider count for {term}"
    },

    # ---- Booking / Performance patterns ----
    r"(?i)(?:booking|appointment)\s+(?:metrics|performance|data)\s+(?:by|for)\s+(?:specialty|spec)": {
        "sql": "SELECT * FROM v_booking_performance ORDER BY total_bookings DESC LIMIT 20",
        "description": "Booking performance by specialty and geography"
    },

    r"(?i)(?:avg|average)\s+(?:cpa|cost per acquisition)\s+(?:by|for)\s+(?:specialty|metro|market)": {
        "sql": """
            SELECT specialty, patient_geo_id,
                   ROUND(AVG(cpa), 2) AS avg_cpa,
                   COUNT(*) AS total_bookings,
                   SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed
            FROM bookings
            WHERE cpa > 0
            GROUP BY specialty, patient_geo_id
            ORDER BY avg_cpa ASC
            LIMIT 20
        """,
        "description": "Average CPA by specialty and market"
    },

    # ---- POI / Segment Ranking patterns ----
    r"(?i)(?:poi|opportunity|segment)\s+(?:rank|ranking|scores?)": {
        "sql": "SELECT * FROM v_poi_ranking LIMIT 15",
        "description": "POI ranking — top segments by opportunity score"
    },

    r"(?i)(?:top|best|highest)\s+(?:segments?|opportunities|poi)": {
        "sql": "SELECT * FROM v_poi_ranking LIMIT 10",
        "description": "Top opportunity segments by POI score"
    },

    r"(?i)(?:gtm|go.to.market)\s+(?:segments?|targets?|recommendations?)": {
        "sql": "SELECT * FROM v_gtm_segments LIMIT 15",
        "description": "GTM target segments with actionable recommendations"
    },

    # ---- Supply-demand gap ----
    r"(?i)(?:supply|demand)\s+(?:gap|mismatch|imbalance)": {
        "sql": """
            SELECT * FROM v_supply_demand_gap
            ORDER BY (demand_score - supply_gap_score) DESC
            LIMIT 15
        """,
        "description": "Supply-demand gap analysis across segments"
    },

    # ---- Monthly / time-based ----
    r"(?i)(?:monthly|month.over.month|mom)\s+(?:bookings?|trends?)": {
        "sql": """
            SELECT strftime('%Y-%m', booked_at) AS month,
                   specialty,
                   COUNT(*) AS bookings,
                   SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
                   ROUND(AVG(cpa), 2) AS avg_cpa,
                   ROUND(SUM(revenue), 2) AS total_revenue
            FROM bookings
            GROUP BY month, specialty
            ORDER BY month DESC, bookings DESC
            LIMIT 50
        """,
        "description": "Monthly booking trends by specialty"
    },

    # ---- General exploration ----
    r"(?i)(?:show|list|get)\s+(?:all\s+)?(?:specialties|specialties\s+available)": {
        "sql": "SELECT DISTINCT specialty FROM providers ORDER BY specialty LIMIT 20",
        "description": "List of available specialties"
    },

    r"(?i)(?:show|list|get)\s+(?:all\s+)?(?:markets?|cities|geos?)": {
        "sql": "SELECT geo_id, city, state, population, provider_density FROM geo_markets ORDER BY population DESC LIMIT 20",
        "description": "List of available markets"
    },
}


class SQLQueryAgent:
    """
    Translates natural-language questions into SQL, executes them,
    and returns structured results.

    Uses template matching first; falls back to LLM if no match.
    """

    def __init__(self, conn, llm_client=None, schema_prompt: str = ""):
        self.conn = conn
        self.llm_client = llm_client
        self.schema_prompt = schema_prompt

    def match_template(self, question: str) -> Optional[dict]:
        """Try to match the question against known SQL templates."""
        for pattern, template in QUERY_TEMPLATES.items():
            match = re.search(pattern, question)
            if match:
                if "sql_template" in template:
                    # Extract params from regex groups
                    groups = match.groups()
                    params = template.get("params", [])
                    sql = template["sql_template"]
                    desc = template["description"]
                    for i, param in enumerate(params):
                        val = groups[i].strip() if i < len(groups) else ""
                        sql = sql.replace(f"{{{param}}}", val)
                        desc = desc.replace(f"{{{param}}}", val)
                    return {"sql": sql.strip(), "description": desc, "source": "template"}
                else:
                    return {
                        "sql": template["sql"].strip(),
                        "description": template["description"],
                        "source": "template"
                    }
        return None

    def generate_sql_via_llm(self, question: str) -> dict:
        """
        Use Claude (or any LLM) to generate SQL from natural language.
        Falls back to a helpful error if no API client is configured.
        """
        if not self.llm_client:
            return {
                "sql": None,
                "description": "No LLM client configured. Use template queries or set ANTHROPIC_API_KEY.",
                "source": "llm_unavailable",
                "error": "LLM client not configured"
            }

        system_prompt = f"""You are a SQL query agent for a healthcare provider demand engine.
You generate SQLite-compatible SELECT queries ONLY. Never generate INSERT, UPDATE, DELETE, DROP, or any DDL.

{self.schema_prompt}

RULES:
- ONLY generate SELECT statements
- Always include a LIMIT clause (max 1000)
- Never reference columns with patient PII (names, emails, phones, SSN, DOB)
- Use the pre-built views (v_poi_ranking, v_demand_signals, etc.) when they fit
- Return ONLY the SQL query, no explanation, no markdown fences
"""

        try:
            response = self.llm_client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=500,
                system=system_prompt,
                messages=[{"role": "user", "content": question}]
            )
            sql = response.content[0].text.strip()
            # Clean markdown fences if present
            sql = re.sub(r"^```(?:sql)?\s*", "", sql)
            sql = re.sub(r"\s*```$", "", sql)
            return {"sql": sql, "description": f"LLM-generated for: {question}", "source": "llm"}
        except Exception as e:
            return {"sql": None, "description": str(e), "source": "llm_error", "error": str(e)}

    def generate(self, question: str) -> dict:
        """
        Main entry point: NL question → SQL result dict.
        Returns: { sql, description, source, results?, error?, latency_ms }
        """
        start = time.time()

        # 1. Try template matching first (fast, no API call)
        result = self.match_template(question)

        # 2. Fall back to LLM generation
        if result is None:
            result = self.generate_sql_via_llm(question)

        result["latency_ms"] = int((time.time() - start) * 1000)
        result["original_question"] = question
        return result

    def generate_and_execute(self, question: str) -> dict:
        """Generate SQL, validate, execute, and return full result."""
        result = self.generate(question)

        if result.get("sql") and not result.get("error"):
            try:
                from src.utils.database import execute_query
                rows = execute_query(self.conn, result["sql"])
                result["results"] = rows
                result["row_count"] = len(rows)
            except Exception as e:
                result["error"] = str(e)
                result["results"] = []
                result["row_count"] = 0

        return result
