"""
POI (Provider Opportunity Index) Scorer
========================================
Computes segment-level opportunity scores from the SQL views
and caches them in the poi_scores table.

Formula:
  POI = (demand_score × 0.35) + (supply_gap_score × 0.25)
      + (conversion_score × 0.20) + (growth_score × 0.20)
"""

import sqlite3
import uuid
from datetime import datetime


class POIScorer:
    """Compute and cache POI scores from the analytical views."""

    WEIGHTS = {
        "demand": 0.35,
        "supply_gap": 0.25,
        "conversion": 0.20,
        "growth": 0.20
    }

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def compute_from_views(self) -> list[dict]:
        """
        Read v_supply_demand_gap view and compute POI scores.
        Returns the ranked list.
        """
        rows = self.conn.execute("SELECT * FROM v_poi_ranking").fetchall()
        columns = [desc[0] for desc in self.conn.execute("SELECT * FROM v_poi_ranking LIMIT 0").description]
        return [dict(zip(columns, row)) for row in rows]

    def cache_scores(self) -> int:
        """
        Compute POI scores and write to the poi_scores table.
        Returns count of rows written.
        """
        rows = self.compute_from_views()

        for row in rows:
            poi_id = f"poi_{uuid.uuid4().hex[:8]}"
            why = self._generate_why(row)

            self.conn.execute("""
                INSERT OR REPLACE INTO poi_scores
                    (poi_id, specialty, geo_id, demand_score, supply_gap_score,
                     conversion_score, growth_score, poi, rank, why_it_matters, scored_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                poi_id,
                row.get("specialty", ""),
                row.get("geo_id", ""),
                row.get("demand_score", 0),
                row.get("supply_gap_score", 0),
                row.get("conversion_score", 0),
                row.get("growth_score", 0),
                row.get("poi", 0),
                row.get("rank", 999),
                why,
                datetime.utcnow().isoformat()
            ))

        self.conn.commit()
        return len(rows)

    def get_top_segments(self, n: int = 10) -> list[dict]:
        """Get top N segments by POI score."""
        rows = self.conn.execute(
            "SELECT * FROM poi_scores ORDER BY poi DESC LIMIT ?", (n,)
        ).fetchall()
        columns = [desc[0] for desc in self.conn.execute("SELECT * FROM poi_scores LIMIT 0").description]
        return [dict(zip(columns, row)) for row in rows]

    def _generate_why(self, row: dict) -> str:
        """Generate a human-readable reason for the POI score."""
        demand = row.get("demand_score", 0) or 0
        supply_gap = row.get("supply_gap_score", 0) or 0
        conversion = row.get("conversion_score", 0) or 0
        growth = row.get("growth_score", 0) or 0

        reasons = []
        if demand > 60:
            reasons.append("high search demand")
        if supply_gap > 70:
            reasons.append("low provider coverage")
        if conversion > 50:
            reasons.append("strong conversion signals")
        if growth > 50:
            reasons.append("rising bookings trend")

        cpa = row.get("avg_cpa", 0)
        if cpa and cpa < 45:
            reasons.append("manageable CPA")
        elif cpa and cpa > 80:
            reasons.append("elevated CPA — optimize spend")

        if not reasons:
            reasons.append("emerging opportunity — monitor")

        return "; ".join(reasons).capitalize()
