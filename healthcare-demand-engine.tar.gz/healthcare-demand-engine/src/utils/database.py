"""
Database utility — manages SQLite connection and schema initialization.
All data models live in SQL. This is a thin wrapper, not an ORM.
"""

import sqlite3
import os
from pathlib import Path

DB_DIR = Path(__file__).resolve().parent.parent.parent / "data"
DB_PATH = DB_DIR / "demand_engine.db"
SQL_DIR = Path(__file__).resolve().parent.parent.parent / "sql"


def get_connection(db_path: str = None) -> sqlite3.Connection:
    """Return a SQLite connection with row_factory for dict-style access."""
    path = db_path or str(DB_PATH)
    if path != ":memory:":
        dirname = os.path.dirname(path)
        if dirname:
            os.makedirs(dirname, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def run_sql_file(conn: sqlite3.Connection, filepath: str) -> None:
    """Execute a .sql file against the connection."""
    with open(filepath, "r") as f:
        sql = f.read()
    conn.executescript(sql)


def init_database(db_path: str = None) -> sqlite3.Connection:
    """Initialize the database: create schema, views, and seed data."""
    conn = get_connection(db_path)

    # 1. Core schema
    schema_file = SQL_DIR / "schemas" / "001_core_schema.sql"
    if schema_file.exists():
        run_sql_file(conn, str(schema_file))
        print(f"  [OK] Schema applied: {schema_file.name}")

    # 2. Analytical views
    views_file = SQL_DIR / "views" / "002_analytical_views.sql"
    if views_file.exists():
        run_sql_file(conn, str(views_file))
        print(f"  [OK] Views applied: {views_file.name}")

    # 3. Seed data
    seed_file = SQL_DIR / "seeds" / "003_seed_data.sql"
    if seed_file.exists():
        run_sql_file(conn, str(seed_file))
        print(f"  [OK] Seed data loaded: {seed_file.name}")

    conn.commit()
    return conn


def execute_query(conn: sqlite3.Connection, sql: str, limit: int = 1000) -> list[dict]:
    """
    Execute a read-only SQL query with row limit enforcement.
    Returns list of dicts.
    """
    # Enforce LIMIT if missing
    sql_upper = sql.strip().upper()
    if "LIMIT" not in sql_upper:
        sql = sql.rstrip().rstrip(";") + f" LIMIT {limit}"

    cursor = conn.execute(sql)
    columns = [desc[0] for desc in cursor.description] if cursor.description else []
    rows = cursor.fetchall()
    return [dict(zip(columns, row)) for row in rows]


def get_table_names(conn: sqlite3.Connection) -> list[str]:
    """List all tables in the database."""
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()
    return [row[0] for row in rows]


def get_view_names(conn: sqlite3.Connection) -> list[str]:
    """List all views in the database."""
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='view' ORDER BY name"
    ).fetchall()
    return [row[0] for row in rows]


def get_row_count(conn: sqlite3.Connection, table: str) -> int:
    """Get row count for a table or view."""
    row = conn.execute(f"SELECT COUNT(*) as cnt FROM [{table}]").fetchone()
    return row[0] if row else 0
