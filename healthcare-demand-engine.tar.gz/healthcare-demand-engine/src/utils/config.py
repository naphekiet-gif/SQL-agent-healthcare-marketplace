"""
Configuration loader — reads YAML configs for schema and guardrails.
"""

import yaml
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parent.parent.parent / "configs"


def load_yaml(filename: str) -> dict:
    filepath = CONFIG_DIR / filename
    with open(filepath, "r") as f:
        return yaml.safe_load(f)


def load_schema_config() -> dict:
    return load_yaml("schema.yaml")


def load_guardrails_config() -> dict:
    return load_yaml("guardrails.yaml")


def get_allowed_tables(guardrails: dict = None) -> list[str]:
    if guardrails is None:
        guardrails = load_guardrails_config()
    tables = guardrails.get("schema_validation", {}).get("allowed_tables", [])
    views = guardrails.get("schema_validation", {}).get("allowed_views", [])
    return tables + views


def get_blocked_operations(guardrails: dict = None) -> list[str]:
    if guardrails is None:
        guardrails = load_guardrails_config()
    return guardrails.get("query_guardrails", {}).get("blocked_operations", [])


def get_blocked_keywords(guardrails: dict = None) -> list[str]:
    if guardrails is None:
        guardrails = load_guardrails_config()
    return guardrails.get("query_guardrails", {}).get("blocked_keywords", [])


def get_schema_prompt(schema: dict = None) -> str:
    """
    Build a plain-text schema reference for the LLM prompt.
    This is what the SQL Query Agent sees when generating SQL.
    """
    if schema is None:
        schema = load_schema_config()

    lines = ["DATABASE SCHEMA REFERENCE", "=" * 40, ""]

    for table_name, table_def in schema.get("tables", {}).items():
        lines.append(f"TABLE: {table_name}")
        lines.append(f"  Description: {table_def.get('description', '')}")
        lines.append("  Columns:")
        for col_name, col_def in table_def.get("columns", {}).items():
            pk = " [PK]" if col_def.get("pk") else ""
            fk = f" [FK→{col_def['fk']}]" if col_def.get("fk") else ""
            desc = col_def.get("description", "")
            lines.append(f"    - {col_name} ({col_def['type']}{pk}{fk}): {desc}")
        lines.append("")

    lines.append("VIEWS (pre-built analytics):")
    for view_name, view_desc in schema.get("views", {}).items():
        lines.append(f"  - {view_name}: {view_desc}")

    lines.append("")
    lines.append(f"Valid specialties: {', '.join(schema.get('specialty_values', []))}")
    lines.append(f"Valid geos: {', '.join(schema.get('geo_values', []))}")

    return "\n".join(lines)
