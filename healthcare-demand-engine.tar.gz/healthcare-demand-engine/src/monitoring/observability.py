"""
Observability & Monitoring
===========================
Structured logging for every agent run.
Tracks: latency, errors, SQL shape, accuracy, segment coverage.

Outputs structured JSON logs compatible with Datadog, Grafana, ELK, etc.
Also writes to the agent_runs table for in-DB audit trail.
"""

import json
import uuid
import time
import sqlite3
import sys
from datetime import datetime
from typing import Optional


class AgentMonitor:
    """
    Logs every agent pipeline run to both stdout (structured JSON)
    and the agent_runs SQLite table.
    """

    def __init__(self, conn: sqlite3.Connection, log_to_stdout: bool = True):
        self.conn = conn
        self.log_to_stdout = log_to_stdout

    def log_run(
        self,
        natural_query: str,
        generated_sql: Optional[str] = None,
        validation_pass: bool = False,
        validation_errors: Optional[list] = None,
        result_row_count: int = 0,
        explanation: Optional[str] = None,
        gtm_suggestions: Optional[list] = None,
        latency_ms: int = 0,
        accuracy_score: float = 0.0,
        error_reason: Optional[str] = None,
        status: str = "success"
    ) -> str:
        """
        Log a complete agent run. Returns the run_id.
        """
        run_id = f"run_{uuid.uuid4().hex[:12]}"
        now = datetime.utcnow().isoformat()

        # Build structured log entry
        log_entry = {
            "run_id": run_id,
            "timestamp": now,
            "natural_query": natural_query,
            "generated_sql": generated_sql,
            "validation_pass": validation_pass,
            "validation_errors": validation_errors or [],
            "result_row_count": result_row_count,
            "explanation_length": len(explanation) if explanation else 0,
            "gtm_test_count": len(gtm_suggestions) if gtm_suggestions else 0,
            "latency_ms": latency_ms,
            "accuracy_score": accuracy_score,
            "status": status,
            "error_reason": error_reason,
        }

        # Write to stdout as structured JSON
        if self.log_to_stdout:
            print(json.dumps(log_entry, default=str), file=sys.stderr)

        # Write to agent_runs table
        try:
            self.conn.execute("""
                INSERT INTO agent_runs
                    (run_id, natural_query, generated_sql, validation_pass,
                     validation_errors, result_row_count, explanation,
                     gtm_suggestions, latency_ms, accuracy_score,
                     error_reason, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                run_id,
                natural_query,
                generated_sql,
                1 if validation_pass else 0,
                json.dumps(validation_errors or []),
                result_row_count,
                explanation,
                json.dumps(gtm_suggestions or []),
                latency_ms,
                accuracy_score,
                error_reason,
                status,
                now
            ))
            self.conn.commit()
        except Exception as e:
            print(json.dumps({"log_error": str(e), "run_id": run_id}), file=sys.stderr)

        return run_id

    def get_run_stats(self, last_n: int = 100) -> dict:
        """Get aggregate stats from recent agent runs."""
        rows = self.conn.execute(f"""
            SELECT
                COUNT(*) as total_runs,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successes,
                SUM(CASE WHEN status = 'validation_fail' THEN 1 ELSE 0 END) as validation_fails,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors,
                ROUND(AVG(latency_ms), 0) as avg_latency_ms,
                ROUND(AVG(accuracy_score), 3) as avg_accuracy,
                ROUND(AVG(result_row_count), 1) as avg_row_count
            FROM (
                SELECT * FROM agent_runs ORDER BY created_at DESC LIMIT {last_n}
            )
        """).fetchone()

        if rows:
            return dict(zip(
                ["total_runs", "successes", "validation_fails", "errors",
                 "avg_latency_ms", "avg_accuracy", "avg_row_count"],
                rows
            ))
        return {}

    def get_error_breakdown(self, last_n: int = 50) -> list[dict]:
        """Get most common error reasons."""
        rows = self.conn.execute(f"""
            SELECT error_reason, COUNT(*) as count
            FROM agent_runs
            WHERE error_reason IS NOT NULL
            GROUP BY error_reason
            ORDER BY count DESC
            LIMIT 10
        """).fetchall()
        return [{"error": row[0], "count": row[1]} for row in rows]


class PipelineTimer:
    """Context manager for timing pipeline stages."""

    def __init__(self):
        self.stages = {}
        self._current = None
        self._start = None

    def start(self, stage: str):
        self._current = stage
        self._start = time.time()

    def stop(self):
        if self._current and self._start:
            elapsed = int((time.time() - self._start) * 1000)
            self.stages[self._current] = elapsed
            self._current = None
            self._start = None

    @property
    def total_ms(self) -> int:
        return sum(self.stages.values())

    def to_dict(self) -> dict:
        return {**self.stages, "total_ms": self.total_ms}
