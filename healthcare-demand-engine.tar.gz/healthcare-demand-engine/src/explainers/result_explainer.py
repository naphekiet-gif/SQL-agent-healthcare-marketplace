"""
Component 3: Result Explainer
===============================
Generates plain-language explanations of SQL query results.
Designed for Growth & Operations Analysts, GTM and Strategy Teams.

Linked data models: bookings, search_events (for context enrichment)

Supports two modes:
  1. LLM-powered (uses Claude API for rich narratives)
  2. Rule-based (template explanations — no API key needed)
"""

from typing import Optional


class ResultExplainer:
    """
    Takes SQL results and generates human-readable explanations.
    Includes pin-reasoning checks (sanity checks on numbers).
    """

    def __init__(self, llm_client=None):
        self.llm_client = llm_client

    def explain(self, question: str, sql: str, results: list[dict],
                description: str = "") -> dict:
        """
        Main entry point: results → plain-language explanation.
        Returns: { explanation, key_findings, pin_checks, ai_generated }
        """
        if not results:
            return {
                "explanation": "The query returned no results. This could mean "
                               "the filters are too narrow or the data doesn't "
                               "cover this segment yet.",
                "key_findings": [],
                "pin_checks": [],
                "ai_generated": True
            }

        # Run pin-reasoning sanity checks
        pin_checks = self._pin_reasoning_checks(results)

        # Try LLM explanation first
        if self.llm_client:
            return self._explain_via_llm(question, sql, results, description, pin_checks)

        # Fallback: rule-based explanation
        return self._explain_rule_based(question, results, description, pin_checks)

    def _explain_rule_based(self, question: str, results: list[dict],
                            description: str, pin_checks: list[str]) -> dict:
        """Generate a template-based explanation from the result structure."""
        row_count = len(results)
        columns = list(results[0].keys()) if results else []

        findings = []
        explanation_parts = [
            f"[AI-Generated Summary] Query: \"{question}\"",
            f"Returned {row_count} row(s) across {len(columns)} column(s).",
            ""
        ]

        # Detect POI/ranking results
        if "poi" in columns and "rank" in columns:
            top = results[0]
            segment = top.get("segment") or f"{top.get('specialty', '?')} - {top.get('city', '?')}"
            poi_val = top.get("poi", 0)
            explanation_parts.append(
                f"The top opportunity segment is **{segment}** with a POI score of {poi_val}."
            )
            findings.append(f"#1 segment: {segment} (POI {poi_val})")

            if row_count >= 3:
                third = results[2]
                seg3 = third.get("segment") or f"{third.get('specialty', '?')} - {third.get('city', '?')}"
                explanation_parts.append(
                    f"Top 3 segments show POI scores ranging from "
                    f"{results[2].get('poi', 0)} to {results[0].get('poi', 0)}."
                )
                findings.append(f"Top 3 range: {results[2].get('poi', 0)} – {results[0].get('poi', 0)}")

        # Detect demand/search results
        elif "search_volume" in columns:
            top = results[0]
            spec = top.get("specialty") or top.get("specialty_filter", "N/A")
            vol = top.get("search_volume", 0)
            explanation_parts.append(
                f"Highest search volume: **{spec}** with {vol} searches."
            )
            findings.append(f"Top specialty by search volume: {spec} ({vol})")

            ctr = top.get("avg_ctr")
            if ctr:
                explanation_parts.append(f"Average CTR for this segment: {ctr:.1%}.")

        # Detect booking performance
        elif "total_bookings" in columns or "avg_cpa" in columns:
            top = results[0]
            spec = top.get("specialty", "N/A")
            bookings = top.get("total_bookings", 0)
            cpa = top.get("avg_cpa", 0)
            explanation_parts.append(
                f"Top performing segment: **{spec}** with {bookings} bookings "
                f"at ${cpa:.2f} average CPA."
            )
            findings.append(f"Top: {spec} — {bookings} bookings, ${cpa:.2f} CPA")

            completion = top.get("completion_rate")
            if completion:
                pct = completion * 100 if completion <= 1 else completion
                explanation_parts.append(f"Completion rate: {pct:.0f}%.")

        # Detect supply metrics
        elif "provider_count" in columns:
            top = results[0]
            spec = top.get("specialty", "N/A")
            count = top.get("provider_count", 0)
            explanation_parts.append(
                f"Highest provider density segment: **{spec}** with {count} providers."
            )
            findings.append(f"Top supply: {spec} ({count} providers)")

        # GTM segments
        elif "why_it_matters" in columns:
            explanation_parts.append("GTM segment recommendations:")
            for i, row in enumerate(results[:5], 1):
                seg = row.get("segment", "N/A")
                poi = row.get("poi", 0)
                why = row.get("why_it_matters", "")
                explanation_parts.append(f"  {i}. {seg} (POI {poi}): {why}")
                findings.append(f"{seg}: {why}")

        # Generic fallback
        else:
            explanation_parts.append(
                f"Results include columns: {', '.join(columns[:8])}."
            )
            if row_count > 1:
                explanation_parts.append(
                    f"First row sample: {dict(list(results[0].items())[:4])}"
                )

        # Add pin checks
        if pin_checks:
            explanation_parts.append("")
            explanation_parts.append("Sanity checks:")
            for check in pin_checks:
                explanation_parts.append(f"  ⚠ {check}")

        return {
            "explanation": "\n".join(explanation_parts),
            "key_findings": findings,
            "pin_checks": pin_checks,
            "ai_generated": True
        }

    def _explain_via_llm(self, question: str, sql: str, results: list[dict],
                         description: str, pin_checks: list[str]) -> dict:
        """Use Claude to generate a rich explanation."""
        # Limit result data sent to LLM
        sample = results[:10]
        results_text = "\n".join([str(row) for row in sample])
        if len(results) > 10:
            results_text += f"\n... and {len(results) - 10} more rows"

        prompt = f"""You are a healthcare analytics advisor explaining SQL query results
to a Growth & Operations Analyst at a healthcare marketplace (like Zocdoc or Headway).

Question asked: "{question}"
SQL executed: {sql}
Description: {description}

Results ({len(results)} rows):
{results_text}

Write a clear, concise summary (3-5 sentences) that:
1. States the key finding
2. Highlights the most actionable data points
3. Notes any notable patterns or outliers
4. Suggests what to investigate next

Start with [AI-Generated Summary] to comply with transparency requirements.
Do NOT include raw SQL or technical jargon. Speak to a business user."""

        try:
            response = self.llm_client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=400,
                messages=[{"role": "user", "content": prompt}]
            )
            explanation = response.content[0].text.strip()
            return {
                "explanation": explanation,
                "key_findings": [],  # LLM handles this inline
                "pin_checks": pin_checks,
                "ai_generated": True
            }
        except Exception as e:
            # Fall back to rule-based
            return self._explain_rule_based(question, results, description, pin_checks)

    def _pin_reasoning_checks(self, results: list[dict]) -> list[str]:
        """
        Sanity-check numerical outputs.
        Flags values that look unreasonable for healthcare marketplace data.
        """
        checks = []
        if not results:
            return checks

        for row in results[:20]:
            # CPA sanity: should be $5-$200 for healthcare
            cpa = row.get("avg_cpa") or row.get("cpa")
            if cpa is not None and cpa > 0:
                if cpa > 200:
                    checks.append(f"High CPA detected: ${cpa:.2f} — verify data source")
                if cpa < 5:
                    checks.append(f"Suspiciously low CPA: ${cpa:.2f} — may be incomplete data")

            # Completion rate sanity: should be 0.5-0.98
            cr = row.get("completion_rate")
            if cr is not None and cr > 0:
                if cr > 1:
                    checks.append(f"Completion rate > 100%: {cr} — likely a calculation error")
                if cr < 0.3:
                    checks.append(f"Very low completion rate: {cr:.0%} — investigate no-show causes")

            # POI sanity: should be 0-100
            poi = row.get("poi")
            if poi is not None:
                if poi > 100:
                    checks.append(f"POI > 100: {poi} — score may need normalization")
                if poi < 0:
                    checks.append(f"Negative POI: {poi} — check scoring formula")

            # Provider count: flag zeros
            pc = row.get("provider_count")
            if pc is not None and pc == 0:
                spec = row.get("specialty", "unknown")
                checks.append(f"Zero providers for {spec} — potential recruitment opportunity")

        return checks[:5]  # Limit to top 5 checks
